<?php
/**
 * Cấu hình kết nối cơ sở dữ liệu.
 * Mặc định khớp với cấu hình MySQL của Laragon (user root, không mật khẩu).
 * Nếu MySQL của bạn có mật khẩu khác, chỉnh lại DB_PASS bên dưới.
 */
$DB_HOST = '127.0.0.1';
$DB_NAME = 'minimart';
$DB_USER = 'root';
$DB_PASS = '';

/**
 * Công tắc phục vụ bài pentest — dùng CHUNG cho cả hai khu vực nhân sự.
 * false (mặc định): /admin VÀ /ctv đều được phân quyền đúng (admin / cộng tác viên / khách).
 * true: tái hiện lỗi Broken Access Control cũ [VULN-A01] ở cả hai nơi — tài khoản nào đã
 *       đăng nhập (kể cả 'customer') cũng vượt qua được kiểm tra quyền:
 *         - has_permission() trong includes/auth.php -> vào được mọi trang /admin
 *         - require_collaborator() trong includes/ctv.php -> vào được mọi trang /ctv
 *       CHỈ bật khi cần chụp bằng chứng "trước khi vá".
 */
if (!defined('KEEP_ADMIN_BAC')) {
    define('KEEP_ADMIN_BAC', false);
}

/**
 * Công tắc cho lỗi [VULN-A05:2025 Injection] ở search.php (tham số "q").
 * false (mặc định): GIỮ NGUYÊN lỗi gốc — nối chuỗi trực tiếp vào SQL (SQL Injection)
 *       và in lại $q không escape (Reflected XSS). Dùng trạng thái này để chụp bằng
 *       chứng "trước khi vá" (ví dụ payload UNION SELECT ở VULN_MAP.md).
 * true: dùng prepared statement (mysqli bind_param) cho phần truy vấn + htmlspecialchars
 *       khi hiển thị lại $q. Dùng trạng thái này để chụp bằng chứng "sau khi vá" — cùng
 *       payload UNION SELECT khi bật cờ này sẽ không còn trả về dữ liệu của bảng khác,
 *       và thẻ <script> trong $q sẽ hiện ra dưới dạng chữ thường, không chạy được.
 */
if (!defined('FIX_SQLI_SEARCH')) {
    define('FIX_SQLI_SEARCH', true);
}

/**
 * Cổng riêng cho cộng tác viên (/ctv).
 * true (mặc định): cộng tác viên đăng nhập xong vào /ctv; gõ URL /admin/... sẽ bị chuyển sang /ctv.
 * false: cộng tác viên dùng chung /admin như trước (menu ẩn theo quyền trong role_permissions()).
 */
if (!defined('CTV_PORTAL_ONLY')) {
    define('CTV_PORTAL_ONLY', true);
}

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    die('Kết nối cơ sở dữ liệu thất bại: ' . $conn->connect_error .
        '<br>Kiểm tra: đã import sql/schema.sql chưa? MySQL trong Laragon đã Start chưa?');
}

$conn->set_charset('utf8mb4');
