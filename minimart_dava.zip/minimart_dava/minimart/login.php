<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

$me = current_user();
$page_title = 'Đăng nhập';
$error = '';

if (isset($_GET['expired'])) {
    // Đến từ require_login(): phiên đã bị thu hồi (đổi mật khẩu / đăng xuất mọi thiết bị).
    $error = 'Phiên đăng nhập đã hết hiệu lực. Vui lòng đăng nhập lại.';
} elseif (isset($_GET['locked'])) {
    // Đến từ require_login() (includes/auth.php): tài khoản bị khoá giữa chừng
    // trong khi phiên vẫn đang mở (ví dụ đăng nhập sẵn ở thiết bị khác).
    $error = 'Tài khoản của bạn đã bị khoá. Bạn đã được đăng xuất. Vui lòng liên hệ quản trị viên.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $logName = mb_substr($username, 0, 64);

    // Giới hạn thử sai: >= 5 lần sai cho cùng một tên đăng nhập, hoặc >= 20 lần sai từ cùng một IP, trong 15 phút -> tạm khoá.
    $c = $conn->prepare("SELECT
            (SELECT COUNT(*) FROM login_attempts WHERE username = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)) AS by_user,
            (SELECT COUNT(*) FROM login_attempts WHERE ip = ?       AND created_at > (NOW() - INTERVAL 15 MINUTE)) AS by_ip");
    $c->bind_param('ss', $logName, $ip);
    $c->execute();
    $fails = $c->get_result()->fetch_assoc();
    $c->close();

    if ((int)$fails['by_user'] >= 5 || (int)$fails['by_ip'] >= 20) {
        $error = 'Bạn đã thử sai quá nhiều lần. Vui lòng thử lại sau 15 phút.';
    } else {
        // Prepared statement: tên đăng nhập chỉ là dữ liệu, không thể thay đổi cấu trúc câu SQL.
        $stmt = $conn->prepare("SELECT id, username, role, is_locked, password, session_version FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && verify_password($password, (string)$user['password'])) {
            if ((int)$user['is_locked'] === 1) {
                // Tài khoản bị quản trị viên khoá (xem admin/users.php) - không cho đăng nhập dù mật khẩu đúng.
                $error = 'Tài khoản của bạn đã bị khoá. Vui lòng liên hệ quản trị viên.';
            } else {
                // Nâng cấp hash md5 cũ (hoặc bcrypt cost cũ) lên bcrypt mới ngay khi đăng nhập đúng.
                if (password_is_legacy_md5((string)$user['password']) || password_needs_rehash((string)$user['password'], PASSWORD_DEFAULT)) {
                    $newHash = hash_password($password);
                    $up = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $up->bind_param('si', $newHash, $user['id']);
                    $up->execute();
                }
                // Xoá lịch sử thử sai của tài khoản này.
                $del = $conn->prepare("DELETE FROM login_attempts WHERE username = ?");
                $del->bind_param('s', $logName);
                $del->execute();

                // Cấp session ID mới sau đăng nhập, chống session fixation.
                session_begin_login((int)$user['session_version']);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                // Cộng tác viên vào thẳng cổng riêng; admin/khách về trang chủ như cũ.
                header('Location: ' . (($user['role'] === 'collaborator' && ctv_portal_only()) ? 'ctv/index.php' : 'index.php'));
                exit;
            }
        } else {
            // Ghi nhận lần thử sai (thông báo chung, không cho biết sai tên hay sai mật khẩu).
            $ins = $conn->prepare("INSERT INTO login_attempts (username, ip) VALUES (?, ?)");
            $ins->bind_param('ss', $logName, $ip);
            $ins->execute();
            $error = 'Tên đăng nhập hoặc mật khẩu không đúng.';
        }
    }
}

require __DIR__ . '/includes/header.php';
?>

<div class="panel" style="max-width:420px;">
  <h2>Đăng nhập</h2>
  <?php if ($error): ?><div class="flash error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
  <form method="post">
    <label for="username">Tên đăng nhập</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Mật khẩu</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Đăng nhập</button>
  </form>
  <p class="muted" style="margin-top:14px;">Chưa có tài khoản? <a href="register.php">Đăng ký</a></p>
  <p class="muted">Tài khoản mẫu: <code>admin/admin123</code> · <code>khach/khach123</code> · <code>ctv/ctv12345</code></p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
