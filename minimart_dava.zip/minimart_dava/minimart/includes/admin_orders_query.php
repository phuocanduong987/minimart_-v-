<?php
/**
 * Dùng chung cho admin/orders.php và admin/export_orders.php: dựng điều kiện lọc đơn hàng
 * từ $_GET (status, q) bằng prepared statement.
 *
 * @return array{0:string,1:string,2:array}  [WHERE sql, kiểu tham số, tham số]
 */
function admin_orders_filter(array $statusList, array $get): array {
    $where = [];
    $types = '';
    $params = [];

    $status = (string)($get['status'] ?? '');
    if ($status !== '' && in_array($status, $statusList, true)) {
        $where[] = 'o.status = ?';
        $types .= 's';
        $params[] = $status;
    }

    $q = trim((string)($get['q'] ?? ''));
    if ($q !== '') {
        $where[] = '(u.username LIKE ? OR o.phone LIKE ? OR o.address LIKE ? OR o.id = ?)';
        $like = '%' . $q . '%';
        $idGuess = ctype_digit(ltrim($q, '#')) ? (int)ltrim($q, '#') : 0;
        $types .= 'sssi';
        array_push($params, $like, $like, $like, $idGuess);
    }

    return [$where ? ' WHERE ' . implode(' AND ', $where) : '', $types, $params];
}
