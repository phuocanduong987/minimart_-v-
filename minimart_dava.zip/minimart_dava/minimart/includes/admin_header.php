<?php
/**
 * Layout dùng chung cho khu vực /admin (thanh bên + phần đầu trang).
 *
 * Biến cần set trước khi include: $me, $page_title, $active_nav
 * Biến tuỳ chọn: $page_subtitle (dòng mô tả dưới tiêu đề), $head_actions (HTML nút ở góc phải)
 *
 * Mỗi trang PHẢI gọi require_permission('<mã quyền>') trước khi include file này
 * (xem includes/auth.php -> role_permissions()). Menu ở đây chỉ ẩn/hiện link theo quyền,
 * còn việc chặn truy cập thật sự nằm ở require_permission() trong từng trang.
 */

require_once __DIR__ . '/admin_icons.php';

// Số liệu nhỏ hiển thị cạnh menu (chỉ đếm khi người dùng có quyền xem mục đó).
$navCounts = ['reviews' => 0, 'orders' => 0, 'payouts' => 0];
try {
    if (has_permission('reviews.reply')) {
        $navCounts['reviews'] = (int)$conn->query(
            "SELECT COUNT(*) c FROM reviews r
             WHERE NOT EXISTS (SELECT 1 FROM review_replies rr JOIN users u ON rr.user_id = u.id
                               WHERE rr.review_id = r.id AND u.role IN ('admin','collaborator'))"
        )->fetch_assoc()['c'];
    }
    if (has_permission('orders.manage')) {
        $navCounts['orders'] = (int)$conn->query(
            "SELECT COUNT(*) c FROM orders WHERE status IN ('Chờ xác nhận','Yêu cầu hoàn hàng')"
        )->fetch_assoc()['c'];
    }
    if (has_permission('payouts.manage')) {
        $navCounts['payouts'] = (int)$conn->query("SELECT COUNT(*) c FROM ctv_payouts WHERE status = 'Chờ duyệt'")->fetch_assoc()['c'];
    }
} catch (Throwable $e) { /* menu vẫn hiển thị bình thường */ }

$navGroups = [
    'Tổng quan' => [
        ['index',    'index.php',    'Bảng điều khiển', 'dashboard', 'dashboard.view'],
    ],
    'Cửa hàng' => [
        ['products', 'products.php', 'Sản phẩm',        'box',       'products.manage'],
        ['reviews',  'reviews.php',  'Đánh giá',        'chat',      'reviews.reply'],
    ],
    'Bán hàng' => [
        ['orders',   'orders.php',   'Đơn hàng',        'receipt',   'orders.manage'],
        ['vouchers', 'vouchers.php', 'Mã giảm giá',     'tag',       'vouchers.manage'],
        ['payouts',  'payouts.php',  'Hoa hồng CTV',    'wallet',    'payouts.manage'],
    ],
    'Hệ thống' => [
        ['users',    'users.php',    'Người dùng',      'users',     'users.manage'],
        ['logs',     'logs.php',     'Nhật ký thao tác','log',       'logs.view'],
    ],
];
$active_nav = $active_nav ?? '';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo htmlspecialchars($page_title ?? 'Quản trị'); ?> - TechNest Quản trị</title>
<link rel="stylesheet" href="../assets/style.css">
<link rel="stylesheet" href="../assets/admin.css">
</head>
<body class="adm-body">
<div class="adm">
  <aside class="adm-side">
    <a class="adm-brand" href="index.php" style="color:#fff;">
      <span class="adm-brand-mark">T</span>
      <span>TechNest<small>Khu vực quản trị</small></span>
    </a>

    <?php foreach ($navGroups as $navGroupTitle => $navItems):
        $navVisible = array_filter($navItems, fn($navIt) => has_permission($navIt[4]));
        if (!$navVisible) continue; ?>
      <div class="adm-group">
        <div class="adm-group-title"><?php echo htmlspecialchars($navGroupTitle); ?></div>
        <?php foreach ($navVisible as [$navKey, $navHref, $navLabel, $navIcon]): ?>
          <a class="adm-link<?php echo $active_nav === $navKey ? ' active' : ''; ?>" href="<?php echo $navHref; ?>">
            <?php echo admin_icon($navIcon); ?><?php echo htmlspecialchars($navLabel); ?>
            <?php if (($navCounts[$navKey] ?? 0) > 0): ?><span class="count"><?php echo (int)$navCounts[$navKey]; ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>

    <div class="adm-side-foot">
      <div class="adm-user"><?php echo htmlspecialchars($me['username']); ?><span><?php echo htmlspecialchars(role_label($me['role'])); ?></span></div>
      <a class="adm-link" href="../index.php"><?php echo admin_icon('home'); ?>Về cửa hàng</a>
      <a class="adm-link" href="../logout.php"><?php echo admin_icon('exit'); ?>Đăng xuất</a>
    </div>
  </aside>

  <main class="adm-main">
    <div class="adm-head">
      <div>
        <h1><?php echo htmlspecialchars($page_title ?? ''); ?></h1>
        <?php if (!empty($page_subtitle)): ?><p><?php echo htmlspecialchars($page_subtitle); ?></p><?php endif; ?>
      </div>
      <?php if (!empty($head_actions)): ?><div class="adm-head-actions"><?php echo $head_actions; ?></div><?php endif; ?>
    </div>
