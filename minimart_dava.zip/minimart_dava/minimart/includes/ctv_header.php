<?php
/**
 * Layout riêng của cổng cộng tác viên (/ctv): thanh điều hướng ngang + nội dung.
 * Dùng lại các lớp CSS bảng/thẻ/nút của admin.css, nhưng khác bố cục & màu (assets/ctv.css).
 *
 * Biến cần set trước khi include: $me, $page_title, $active_nav
 * Biến tuỳ chọn: $page_subtitle, $head_actions
 * Mỗi trang PHẢI gọi require_collaborator() trước khi include file này.
 */
require_once __DIR__ . '/admin_icons.php';

$ctvNav = [
    ['index',     'index.php',     'Tổng quan',       'dashboard'],
    ['products',  'products.php',  'Sản phẩm',        'box'],
    ['reviews',   'reviews.php',   'Đánh giá',        'chat'],
    ['referrals', 'referrals.php', 'Giới thiệu',      'link'],
    ['payouts',   'payouts.php',   'Hoa hồng & rút',  'wallet'],
];
$ctvPendingReviews = 0;
try { $ctvPendingReviews = ctv_pending_reviews_count($conn, (int)$me['id']); } catch (Throwable $e) {}
$active_nav = $active_nav ?? '';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo htmlspecialchars($page_title ?? 'Cộng tác viên'); ?> - TechNest Cộng tác viên</title>
<link rel="stylesheet" href="../assets/style.css">
<link rel="stylesheet" href="../assets/admin.css">
<link rel="stylesheet" href="../assets/ctv.css">
</head>
<body class="adm-body ctv-body">
<header class="ctv-top">
  <div class="ctv-top-in">
    <a class="ctv-brand" href="index.php"><span class="ctv-mark">T</span><span>TechNest <small>Cộng tác viên</small></span></a>
    <nav class="ctv-nav" aria-label="Điều hướng cộng tác viên">
      <?php foreach ($ctvNav as [$k, $href, $label, $icon]): ?>
        <a class="ctv-link<?php echo $active_nav === $k ? ' active' : ''; ?>" href="<?php echo $href; ?>">
          <?php echo admin_icon($icon); ?><span><?php echo htmlspecialchars($label); ?></span>
          <?php if ($k === 'reviews' && $ctvPendingReviews > 0): ?><span class="count"><?php echo $ctvPendingReviews; ?></span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="ctv-user">
      <a class="ctv-me" href="../profile.php" title="Hồ sơ cá nhân"><?php echo htmlspecialchars($me['username']); ?></a>
      <!--
        Hiển thị ĐÚNG vai trò thật của người đang đăng nhập (giống includes/admin_header.php),
        thay vì chỉ ghi tên. Nhãn "Cộng tác viên" cạnh logo ở trên chỉ là tên cổng, không phải
        vai trò thật -> nếu không có tag này, một tài khoản 'customer' lọt vào /ctv qua lỗi BAC
        (xem require_collaborator() trong includes/ctv.php) sẽ trông y hệt một cộng tác viên
        thật trên giao diện, dù vai trò thật trong DB vẫn là 'customer'.
      -->
      <span class="tag role-<?php echo htmlspecialchars($me['role']); ?>"><?php echo htmlspecialchars(role_label($me['role'])); ?></span>
      <a class="ctv-ico" href="../index.php" title="Xem cửa hàng"><?php echo admin_icon('home'); ?></a>
      <a class="ctv-ico" href="../logout.php" title="Đăng xuất"><?php echo admin_icon('exit'); ?></a>
    </div>
  </div>
</header>

<main class="adm ctv-main">
  <div class="adm-head">
    <div>
      <h1><?php echo htmlspecialchars($page_title ?? ''); ?></h1>
      <?php if (!empty($page_subtitle)): ?><p><?php echo htmlspecialchars($page_subtitle); ?></p><?php endif; ?>
    </div>
    <?php if (!empty($head_actions)): ?><div class="adm-head-actions"><?php echo $head_actions; ?></div><?php endif; ?>
  </div>
