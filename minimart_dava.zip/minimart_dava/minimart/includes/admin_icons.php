<?php
/** Icon SVG + thông báo dùng chung cho khu vực /admin và cổng /ctv. */

if (!function_exists('admin_icon')) {
    function admin_icon(string $name): string {
        $paths = [
            'dashboard' => '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
            'box'       => '<path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
            'chat'      => '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/>',
            'receipt'   => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/>',
            'tag'       => '<path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="7.5" cy="8.5" r="1.3"/>',
            'users'     => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.2A6.5 6.5 0 0 1 21.5 20"/>',
            'log'       => '<path d="M8 4h11v16H8z"/><path d="M4 8h4M4 12h4M4 16h4M11 9h5M11 13h5"/>',
            'home'      => '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
            'link'      => '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
            'wallet'    => '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-3"/><path d="M21 9H6a3 3 0 0 1-3-2"/><path d="M21 12v4h-4a2 2 0 0 1 0-4h4Z"/>',
            'exit'      => '<path d="M14 4h5v16h-5M10 8l-4 4 4 4M6 12h10"/>',
        ];
        return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
             . ($paths[$name] ?? '') . '</svg>';
    }

    /** In thông báo thành công / lỗi dùng chung. */
    function admin_flash(string $flash = '', string $error = ''): void {
        if ($flash !== '') echo '<div class="flash ok">' . htmlspecialchars($flash) . '</div>';
        if ($error !== '') echo '<div class="flash error">' . htmlspecialchars($error) . '</div>';
    }
}
