  </main>
</div>
<script>
// Nút "Sao chép" cho link giới thiệu
document.querySelectorAll('[data-copy]').forEach(function (btn) {
  btn.addEventListener('click', function () {
    var el = document.getElementById(btn.getAttribute('data-copy'));
    if (!el) return;
    var text = el.value !== undefined ? el.value : el.textContent;
    var done = function () { var old = btn.textContent; btn.textContent = 'Đã sao chép ✓'; setTimeout(function () { btn.textContent = old; }, 1600); };
    if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done); }
    else { if (el.select) el.select(); document.execCommand('copy'); done(); }
  });
});
</script>
</body>
</html>
