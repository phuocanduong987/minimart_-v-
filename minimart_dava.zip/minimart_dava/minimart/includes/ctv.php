<?php
/**
 * Hàm dùng chung cho cổng cộng tác viên (/ctv) và trang duyệt rút tiền của admin.
 *
 * Quy tắc hoa hồng (đơn giản, minh bạch):
 *  - Đơn tính hoa hồng khi khách đặt hàng qua link ?ref=<mã> của cộng tác viên (cookie 30 ngày).
 *  - Hoa hồng = giá trị hàng hoá trong đơn (Σ giá × số lượng, chưa gồm phí ship) × tỷ lệ % chốt lúc đặt.
 *  - Đơn "Đã giao" (hoặc "Từ chối hoàn hàng") -> hoa hồng ĐÃ GHI NHẬN, được phép rút.
 *  - Đơn "Đã hủy" / "Đã hoàn hàng" -> không có hoa hồng.
 *  - Các trạng thái còn lại -> CHỜ ĐỐI SOÁT.
 */

const CTV_MIN_PAYOUT = 100000;      // số tiền rút tối thiểu (đ)
const CTV_REF_COOKIE = 'ctv_ref';

/**
 * Chặn người không phải cộng tác viên. Admin được chuyển về /admin, khách nhận 403.
 */
function require_collaborator(): void {
    require_login('../login.php');

    /*
     * [VULN-A01 Broken Access Control] Dùng chung công tắc KEEP_ADMIN_BAC với khu vực
     * /admin (xem has_permission() trong includes/auth.php và config/db.php). Khi bật,
     * BẤT KỲ tài khoản nào đã đăng nhập (kể cả 'customer') đều vượt qua được kiểm tra
     * vai trò ở đây và vào thẳng cổng cộng tác viên /ctv, dù role_permissions() không
     * cấp quyền 'dashboard.view' cho khách. Mặc định false = kiểm tra vai trò đúng.
     * Kiểm thử gợi ý: đăng nhập khach/khach123, đặt KEEP_ADMIN_BAC = true, gõ /ctv/index.php.
     * Xem WSTG-ATHZ-01 / WSTG-ATHZ-02.
     */
    if (defined('KEEP_ADMIN_BAC') && KEEP_ADMIN_BAC === true) {
        return;
    }

    if (is_collaborator()) {
        return;
    }
    if (is_admin()) {
        header('Location: ../admin/index.php');
        exit;
    }
    http_response_code(403);
    echo '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Không đủ quyền - TechNest</title>'
       . '<link rel="stylesheet" href="../assets/style.css"></head><body>'
       . '<div class="wrap"><div class="panel" style="max-width:480px;margin:60px auto;">'
       . '<h2>Khu vực dành cho cộng tác viên</h2>'
       . '<p class="muted">Tài khoản của bạn (' . htmlspecialchars(role_label(current_role())) . ') không có quyền truy cập cổng này.</p>'
       . '<a class="btn" href="../index.php">Về trang chủ</a></div></div></body></html>';
    exit;
}

/* ---------- Mã giới thiệu & link ---------- */

/** Lấy mã giới thiệu của cộng tác viên; chưa có thì tạo (mã duy nhất, dạng CTV + 6 ký tự). */
function ctv_ensure_ref_code(mysqli $conn, int $userId): string {
    $stmt = $conn->prepare("SELECT ref_code FROM users WHERE id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $code = (string)($stmt->get_result()->fetch_row()[0] ?? '');
    $stmt->close();
    if ($code !== '') {
        return $code;
    }
    for ($i = 0; $i < 8; $i++) {
        $code = 'CTV' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        try {
            $up = $conn->prepare("UPDATE users SET ref_code = ? WHERE id = ? AND ref_code IS NULL");
            $up->bind_param('si', $code, $userId);
            $up->execute();
            if ($up->affected_rows > 0) {
                return $code;
            }
            // Có tiến trình khác vừa gán mã cho user này -> đọc lại.
            $re = $conn->prepare("SELECT ref_code FROM users WHERE id = ?");
            $re->bind_param('i', $userId);
            $re->execute();
            $existing = (string)($re->get_result()->fetch_row()[0] ?? '');
            if ($existing !== '') {
                return $existing;
            }
        } catch (mysqli_sql_exception $e) {
            // Trùng mã (UNIQUE) -> thử mã khác.
        }
    }
    return '';
}

/** Link giới thiệu tuyệt đối tới trang chủ (hoặc một sản phẩm). Gọi từ trang nằm trong /ctv. */
function ctv_referral_link(string $code, int $productId = 0): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $root = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/ctv/index.php'))), '/');
    $path = $productId > 0 ? 'product.php?id=' . $productId . '&ref=' : 'index.php?ref=';
    return ($https ? 'https://' : 'http://') . $host . $root . '/' . $path . rawurlencode($code);
}

/* ---------- Gắn đơn hàng với cộng tác viên (gọi sau khi tạo đơn) ---------- */

/**
 * Nếu khách đến từ link giới thiệu hợp lệ thì ghi cộng tác viên + tỷ lệ hoa hồng vào đơn.
 * Bỏ qua lặng lẽ nếu không có cookie / mã sai / cộng tác viên bị khoá / chưa chạy migration,
 * để không bao giờ làm hỏng bước đặt hàng.
 */
function ctv_attach_referral(mysqli $conn, int $orderId, int $buyerId): void {
    $code = $_COOKIE[CTV_REF_COOKIE] ?? '';
    if (!is_string($code) || !preg_match('/^[A-Z0-9]{4,20}$/', $code)) {
        return;
    }
    try {
        $stmt = $conn->prepare(
            "SELECT id, commission_rate FROM users
             WHERE ref_code = ? AND role = 'collaborator' AND is_locked = 0 AND id <> ?"
        );
        $stmt->bind_param('si', $code, $buyerId);
        $stmt->execute();
        $ctv = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$ctv) {
            return;
        }
        $up = $conn->prepare("UPDATE orders SET ref_ctv_id = ?, ctv_rate = ? WHERE id = ? AND ref_ctv_id IS NULL");
        $ctvId = (int)$ctv['id'];
        $rate = (float)$ctv['commission_rate'];
        $up->bind_param('idi', $ctvId, $rate, $orderId);
        $up->execute();
    } catch (Throwable $e) {
        // bỏ qua
    }
}

/* ---------- Hoa hồng ---------- */

/** earned = đã ghi nhận, pending = chờ đối soát, void = không có hoa hồng. */
function ctv_commission_state(string $orderStatus): string {
    if (in_array($orderStatus, ['Đã giao', 'Từ chối hoàn hàng'], true)) return 'earned';
    if (in_array($orderStatus, ['Đã hủy', 'Đã hoàn hàng'], true)) return 'void';
    return 'pending';
}

function ctv_state_label(string $state): array {
    switch ($state) {
        case 'earned': return ['Đã ghi nhận', 'ok'];
        case 'void':   return ['Không tính', 'bad'];
        default:       return ['Chờ đối soát', 'warn'];
    }
}

/**
 * Các đơn do cộng tác viên giới thiệu, kèm giá trị hàng hoá và hoa hồng.
 * @return array<int,array<string,mixed>>
 */
function ctv_orders(mysqli $conn, int $ctvId, int $limit = 0): array {
    $sql = "SELECT o.id, o.status, o.created_at, o.ctv_rate, u.username,
                   COALESCE(SUM(oi.price * oi.quantity), 0) AS base,
                   COALESCE(SUM(oi.quantity), 0) AS qty
            FROM orders o
            JOIN users u ON u.id = o.user_id
            LEFT JOIN order_items oi ON oi.order_id = o.id
            WHERE o.ref_ctv_id = ?
            GROUP BY o.id, o.status, o.created_at, o.ctv_rate, u.username
            ORDER BY o.id DESC";
    if ($limit > 0) {
        $sql .= ' LIMIT ' . (int)$limit;
    }
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $ctvId);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    foreach ($rows as &$r) {
        $r['state'] = ctv_commission_state((string)$r['status']);
        $r['commission'] = $r['state'] === 'void' ? 0.0 : round((float)$r['base'] * (float)$r['ctv_rate'] / 100);
        // Tên khách chỉ hiện dạng che bớt: cộng tác viên không cần biết đầy đủ.
        $r['customer'] = ctv_mask_name((string)$r['username']);
    }
    unset($r);
    return $rows;
}

function ctv_mask_name(string $name): string {
    $len = mb_strlen($name);
    if ($len <= 2) return mb_substr($name, 0, 1) . '*';
    return mb_substr($name, 0, 2) . str_repeat('*', min(4, $len - 2));
}

/**
 * Tổng hợp số dư hoa hồng.
 * available = đã ghi nhận − đã chi − đang chờ duyệt rút.
 * @return array{earned:float,pending:float,paid:float,reserved:float,available:float,orders:int}
 */
function ctv_balance(mysqli $conn, int $ctvId): array {
    $earned = 0.0; $pending = 0.0;
    $orders = ctv_orders($conn, $ctvId);
    foreach ($orders as $o) {
        if ($o['state'] === 'earned') $earned += $o['commission'];
        elseif ($o['state'] === 'pending') $pending += $o['commission'];
    }
    $stmt = $conn->prepare("SELECT status, COALESCE(SUM(amount),0) s FROM ctv_payouts WHERE user_id = ? GROUP BY status");
    $stmt->bind_param('i', $ctvId);
    $stmt->execute();
    $by = [];
    foreach ($stmt->get_result() as $r) $by[$r['status']] = (float)$r['s'];
    $stmt->close();
    $paid = $by['Đã chi'] ?? 0.0;
    $reserved = $by['Chờ duyệt'] ?? 0.0;
    return [
        'earned'    => $earned,
        'pending'   => $pending,
        'paid'      => $paid,
        'reserved'  => $reserved,
        'available' => max(0.0, $earned - $paid - $reserved),
        'orders'    => count($orders),
    ];
}

/**
 * Tạo yêu cầu rút tiền. Khoá dòng user trong transaction để hai yêu cầu cùng lúc
 * không thể rút vượt số dư.
 * @return array{ok:bool,message:string}
 */
function ctv_request_payout(mysqli $conn, int $ctvId, float $amount, string $bankInfo): array {
    $amount = round($amount);
    if ($amount < CTV_MIN_PAYOUT) {
        return ['ok' => false, 'message' => 'Số tiền rút tối thiểu là ' . vnd(CTV_MIN_PAYOUT) . '.'];
    }
    $bankInfo = trim($bankInfo);
    if ($bankInfo === '' || mb_strlen($bankInfo) > 255) {
        return ['ok' => false, 'message' => 'Vui lòng nhập thông tin nhận tiền (ngân hàng, số tài khoản, tên chủ tài khoản).'];
    }
    $conn->begin_transaction();
    try {
        $lock = $conn->prepare("SELECT id FROM users WHERE id = ? FOR UPDATE");
        $lock->bind_param('i', $ctvId);
        $lock->execute();
        $lock->close();

        $bal = ctv_balance($conn, $ctvId);
        if ($amount > $bal['available']) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'Số tiền vượt quá số dư có thể rút (' . vnd($bal['available']) . ').'];
        }
        $ins = $conn->prepare("INSERT INTO ctv_payouts (user_id, amount, bank_info) VALUES (?, ?, ?)");
        $ins->bind_param('ids', $ctvId, $amount, $bankInfo);
        $ins->execute();
        $conn->commit();
        return ['ok' => true, 'message' => 'Đã gửi yêu cầu rút ' . vnd($amount) . '. Quản trị viên sẽ duyệt sớm.'];
    } catch (Throwable $e) {
        $conn->rollback();
        return ['ok' => false, 'message' => 'Không thể gửi yêu cầu, vui lòng thử lại.'];
    }
}

function ctv_payout_tone(string $status): string {
    return $status === 'Đã chi' ? 'ok' : ($status === 'Từ chối' ? 'bad' : 'warn');
}

/* ---------- Sản phẩm của cộng tác viên ---------- */

/** Sản phẩm này có phải do cộng tác viên $ctvId tạo không (điều kiện để được sửa / nhập kho). */
function ctv_owns_product(mysqli $conn, int $ctvId, int $productId): bool {
    $stmt = $conn->prepare("SELECT 1 FROM products WHERE id = ? AND created_by = ?");
    $stmt->bind_param('ii', $productId, $ctvId);
    $stmt->execute();
    $ok = (bool)$stmt->get_result()->fetch_row();
    $stmt->close();
    return $ok;
}

/** Đánh giá chưa có phản hồi từ nhân sự, thuộc sản phẩm của cộng tác viên. */
function ctv_pending_reviews_count(mysqli $conn, int $ctvId): int {
    $stmt = $conn->prepare(
        "SELECT COUNT(*) FROM reviews r JOIN products p ON p.id = r.product_id
         WHERE p.created_by = ? AND NOT EXISTS (
            SELECT 1 FROM review_replies rr JOIN users x ON x.id = rr.user_id
            WHERE rr.review_id = r.id AND x.role IN ('admin','collaborator'))"
    );
    $stmt->bind_param('i', $ctvId);
    $stmt->execute();
    $n = (int)$stmt->get_result()->fetch_row()[0];
    $stmt->close();
    return $n;
}

/* ---------- Tỷ lệ hoa hồng ---------- */

function ctv_commission_rate(mysqli $conn, int $ctvId): float {
    $stmt = $conn->prepare("SELECT commission_rate FROM users WHERE id = ?");
    $stmt->bind_param('i', $ctvId);
    $stmt->execute();
    $rate = (float)($stmt->get_result()->fetch_row()[0] ?? 0);
    $stmt->close();
    return $rate;
}

/** 5.0 -> "5", 7.5 -> "7,5" */
function ctv_pct($rate): string {
    $s = rtrim(rtrim(number_format((float)$rate, 1, ',', ''), '0'), ',');
    return $s === '' ? '0' : $s;
}
