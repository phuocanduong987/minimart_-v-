<?php
/**
 * Quản lý session đăng nhập.
 *
 * - Cookie phiên: HttpOnly (JS không đọc được), SameSite=Lax (giảm CSRF), Secure khi chạy HTTPS.
 * - Phiên tự hết hạn sau 30 phút không hoạt động (SESSION_IDLE_TIMEOUT).
 * - Mật khẩu băm bằng bcrypt (hash_password / verify_password); hash md5 cũ vẫn đăng nhập được
 *   và được tự nâng cấp lên bcrypt ở lần đăng nhập đúng kế tiếp.
 */
/*
 * Link giới thiệu của cộng tác viên: ?ref=CTV0003 -> nhớ mã trong cookie 30 ngày.
 * Chỉ nhận mã đúng định dạng; việc mã có hợp lệ hay không được kiểm tra lúc tạo đơn
 * (ctv_attach_referral() trong includes/ctv.php). Cookie này tách biệt với PHPSESSID.
 */
if (isset($_GET['ref']) && is_string($_GET['ref']) && !headers_sent()
    && preg_match('/^[A-Za-z0-9]{4,20}$/', $_GET['ref'])) {
    setcookie('ctv_ref', strtoupper($_GET['ref']), [
        'expires'  => time() + 30 * 86400,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

// Chống session fixation: chỉ nhận ID phiên từ cookie (không từ URL) và từ chối ID do client tự đặt
// mà server chưa từng cấp (use_strict_mode).
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

const SESSION_IDLE_TIMEOUT = 1800;       // 30 phút không hoạt động
const SESSION_ABSOLUTE_TIMEOUT = 28800;  // tối đa 8 giờ kể từ lúc đăng nhập, dù vẫn đang hoạt động

// Phiên bị coi là không hợp lệ nếu: quá hạn tuyệt đối, hoặc trình duyệt (User-Agent) khác với lúc đăng nhập.
// Cookie bị chép sang một trình duyệt/công cụ khác sẽ không dùng được nữa (trừ khi kẻ tấn công cũng sao chép được User-Agent).
if (isset($_SESSION['user_id'])) {
    $uaNow = hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
    $tooOld = isset($_SESSION['started_at']) && (time() - (int)$_SESSION['started_at']) > SESSION_ABSOLUTE_TIMEOUT;
    $uaChanged = isset($_SESSION['ua_hash']) && !hash_equals((string)$_SESSION['ua_hash'], $uaNow);
    if ($tooOld || $uaChanged) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
}

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['last_activity']) && (time() - (int)$_SESSION['last_activity']) > SESSION_IDLE_TIMEOUT) {
        $_SESSION = [];
        session_regenerate_id(true);
    } else {
        $_SESSION['last_activity'] = time();
    }
}

/* ---------- Cấp / thu hồi phiên ---------- */

/** Gọi ngay sau khi xác thực thành công: cấp session ID mới và gắn phiên với trình duyệt + phiên bản phiên của user. */
function session_begin_login(int $sessionVersion): void {
    session_regenerate_id(true);
    unset($_SESSION['csrf']); // token CSRF của phiên trước không dùng lại cho phiên mới
    $_SESSION['last_activity'] = time();
    $_SESSION['started_at'] = time();
    $_SESSION['ua_hash'] = hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
    $_SESSION['sv'] = $sessionVersion;
}

/**
 * Thu hồi MỌI phiên đang đăng nhập của $userId (mọi thiết bị) bằng cách tăng users.session_version.
 * $keepCurrent = true: phiên của chính người đang thao tác vẫn giữ (dùng khi đổi mật khẩu / "đăng xuất mọi thiết bị").
 */
function revoke_user_sessions(mysqli $conn, int $userId, bool $keepCurrent = false): void {
    $up = $conn->prepare("UPDATE users SET session_version = session_version + 1 WHERE id = ?");
    $up->bind_param('i', $userId);
    $up->execute();
    $up->close();
    if ($keepCurrent && (int)($_SESSION['user_id'] ?? 0) === $userId) {
        $q = $conn->prepare("SELECT session_version FROM users WHERE id = ?");
        $q->bind_param('i', $userId);
        $q->execute();
        $_SESSION['sv'] = (int)$q->get_result()->fetch_row()[0];
        $q->close();
    }
}

/* ---------- Mật khẩu ---------- */

/** Băm mật khẩu bằng bcrypt (có salt ngẫu nhiên, chậm có chủ đích). */
function hash_password(string $plain): string {
    return password_hash($plain, PASSWORD_DEFAULT);
}

/** Hash cũ dạng md5 (32 ký tự hex) của dữ liệu trước khi vá. */
function password_is_legacy_md5(string $stored): bool {
    return (bool)preg_match('/^[a-f0-9]{32}$/i', $stored);
}

/** Kiểm tra mật khẩu; hỗ trợ cả hash md5 cũ để tài khoản hiện có vẫn đăng nhập được. */
function verify_password(string $plain, string $stored): bool {
    if (password_is_legacy_md5($stored)) {
        return hash_equals(strtolower($stored), md5($plain));
    }
    return password_verify($plain, $stored);
}

function current_user(): ?array {
    global $conn;
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $stmt = $conn->prepare("SELECT id, username, email, role, avatar, session_version FROM users WHERE id = ?");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();
    // Phiên đã bị thu hồi (đổi mật khẩu / "đăng xuất mọi thiết bị" / admin đặt lại mật khẩu) -> coi như chưa đăng nhập.
    if ($user && (int)$user['session_version'] !== (int)($_SESSION['sv'] ?? 0)) {
        $_SESSION = [];
        return null;
    }
    if ($user) {
        // Role có thể vừa được admin đổi (nâng/hạ quyền) -> luôn lấy từ DB, không tin session cũ.
        $_SESSION['role'] = $user['role'];
    }
    return $user ?: null;
}

/**
 * Chỉ kiểm tra "đã đăng nhập hay chưa".
 *
 * [VULN-A01 Broken Access Control] Cố ý KHÔNG có hàm require_admin() kiểm tra
 * $_SESSION['role'] === 'admin'. Các trang trong /admin chỉ gọi require_login(),
 * nên bất kỳ người dùng đã đăng nhập (customer) đều có thể vào được khu vực quản trị
 * nếu biết/đoán được URL. Xem WSTG-ATHZ-01 / WSTG-ATHZ-02.
 *
 * Có kiểm tra riêng (không thuộc các lỗi cố ý ở trên): nếu tài khoản bị admin khoá
 * (is_locked, xem admin/users.php) sau khi phiên đã được tạo — ví dụ đang đăng nhập
 * sẵn ở một thiết bị khác — thì huỷ phiên và đưa về trang đăng nhập ngay tại đây,
 * TRƯỚC khi trang gọi current_user(). Nhờ vậy mọi trang đã gọi require_login() có
 * thể yên tâm rằng current_user() sau đó sẽ không bao giờ trả về null vì lý do này.
 */
function require_login(string $login_path = 'login.php'): void {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . $login_path);
        exit;
    }

    global $conn;
    $stmt = $conn->prepare("SELECT is_locked, role, session_version FROM users WHERE id = ?");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row || (int)$row['is_locked'] === 1) {
        $_SESSION = [];
        session_destroy();
        $separator = (strpos($login_path, '?') === false) ? '?' : '&';
        header('Location: ' . $login_path . $separator . 'locked=1');
        exit;
    }

    // Phiên đã bị thu hồi (xem revoke_user_sessions) -> bắt đăng nhập lại.
    if ((int)$row['session_version'] !== (int)($_SESSION['sv'] ?? 0)) {
        $_SESSION = [];
        session_destroy();
        $separator = (strpos($login_path, '?') === false) ? '?' : '&';
        header('Location: ' . $login_path . $separator . 'expired=1');
        exit;
    }

    $_SESSION['role'] = $row['role']; // đồng bộ vai trò mới nhất từ DB
}

function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

function current_role(): string {
    return $_SESSION['role'] ?? 'customer';
}

function is_admin(): bool {
    return current_role() === 'admin';
}

function is_collaborator(): bool {
    return current_role() === 'collaborator';
}

/** Nhân sự cửa hàng: admin hoặc cộng tác viên. */
function is_staff(): bool {
    return is_admin() || is_collaborator();
}

/**
 * Cộng tác viên dùng cổng riêng /ctv thay vì khu vực /admin?
 * Đặt CTV_PORTAL_ONLY = false trong config/db.php để quay lại cách cũ
 * (cộng tác viên dùng chung /admin với menu bị ẩn bớt).
 */
function ctv_portal_only(): bool {
    return !defined('CTV_PORTAL_ONLY') || CTV_PORTAL_ONLY === true;
}

/** Đường dẫn trang chủ dành cho nhân sự, tính từ thư mục gốc site (dùng ở checkout.php, header.php...). */
function staff_home_path(): string {
    return (is_collaborator() && ctv_portal_only()) ? 'ctv/index.php' : 'admin/index.php';
}

/** Tên vai trò hiển thị cho người dùng. */
function role_label(string $role): string {
    switch ($role) {
        case 'admin': return 'Quản trị viên';
        case 'collaborator': return 'Cộng tác viên';
        default: return 'Khách hàng';
    }
}

/**
 * Bảng phân quyền theo vai trò. Muốn cho cộng tác viên làm thêm việc gì,
 * chỉ cần thêm mã quyền vào mảng 'collaborator' bên dưới.
 *
 *  dashboard.view   xem bảng điều khiển (cộng tác viên chỉ thấy số liệu sản phẩm/đánh giá)
 *  products.manage  thêm / sửa sản phẩm
 *  products.delete  xoá sản phẩm
 *  reviews.reply    trả lời đánh giá của khách
 *  reviews.delete   xoá đánh giá / trả lời
 *  orders.manage    xem, đổi trạng thái, xuất đơn hàng
 *  vouchers.manage  quản lý mã giảm giá
 *  users.manage     quản lý người dùng, đổi vai trò
 *  logs.view        xem nhật ký thao tác
 */
function role_permissions(): array {
    return [
        'admin'        => ['*'],
        'collaborator' => ['dashboard.view', 'products.manage', 'reviews.reply', 'orders.manage'],
        'customer'     => [],
    ];
}

function has_permission(string $permission): bool {
    if (!is_logged_in()) {
        return false;
    }
    /*
     * Công tắc cho bài pentest: đặt KEEP_ADMIN_BAC = true trong config/db.php
     * để tái hiện lỗi [VULN-A01] cũ (mọi tài khoản đã đăng nhập đều vào được /admin).
     * Mặc định là false = phân quyền hoạt động đúng.
     */
    if (defined('KEEP_ADMIN_BAC') && KEEP_ADMIN_BAC === true) {
        return true;
    }
    $perms = role_permissions()[current_role()] ?? [];
    return in_array('*', $perms, true) || in_array($permission, $perms, true);
}

/**
 * Chặn truy cập nếu thiếu quyền: chưa đăng nhập -> về trang đăng nhập;
 * đã đăng nhập nhưng không đủ quyền -> trang 403.
 */
function require_permission(string $permission, string $login_path = '../login.php'): void {
    require_login($login_path);

    // Cộng tác viên có cổng riêng: gõ URL /admin/... sẽ được chuyển sang /ctv.
    // (Không áp dụng khi bật KEEP_ADMIN_BAC để không làm sai lệch bài lab Broken Access Control.)
    if (strpos($login_path, '../') === 0 && is_collaborator() && ctv_portal_only()
        && !(defined('KEEP_ADMIN_BAC') && KEEP_ADMIN_BAC === true)) {
        header('Location: ../ctv/index.php');
        exit;
    }
    if (!has_permission($permission)) {
        http_response_code(403);
        $home = strpos($login_path, '../') === 0 ? '../index.php' : 'index.php';
        echo '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Không đủ quyền - TechNest</title>'
           . '<link rel="stylesheet" href="' . (strpos($login_path, '../') === 0 ? '../' : '') . 'assets/style.css"></head><body>'
           . '<div class="wrap"><div class="panel" style="max-width:480px;margin:60px auto;">'
           . '<h2>Bạn không có quyền truy cập</h2>'
           . '<p class="muted">Tài khoản của bạn (' . htmlspecialchars(role_label(current_role())) . ') không được phép dùng chức năng này.</p>'
           . '<a class="btn" href="' . $home . '">Về trang chủ</a></div></div></body></html>';
        exit;
    }
}

/**
 * Chỉ tài khoản khách hàng mới được mua hàng. Admin và cộng tác viên là người bán
 * nên không được đặt hàng trên chính cửa hàng của mình.
 */
function can_purchase(): bool {
    return is_logged_in() && current_role() === 'customer';
}

/** Chặn mua hàng ở phía server (dùng ở checkout.php, checkout_cart.php). */
function purchase_block_message(): string {
    return 'Tài khoản quản trị / cộng tác viên không thể mua hàng trên cửa hàng. Hãy dùng tài khoản khách hàng riêng nếu cần kiểm thử.';
}

/* ---------- CSRF cho các thao tác trong khu vực quản trị ---------- */

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . htmlspecialchars(csrf_token()) . '">';
}

/** Gọi ở đầu mỗi trang admin: mọi POST phải mang token CSRF hợp lệ. */
function admin_require_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }
    $sent = (string)($_POST['csrf'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        http_response_code(403);
        die('Phiên làm việc đã hết hạn hoặc yêu cầu không hợp lệ. Hãy quay lại và tải lại trang.');
    }
}
