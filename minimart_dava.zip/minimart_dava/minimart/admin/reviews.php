<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

// Trả lời đánh giá: admin + cộng tác viên. Xoá đánh giá/trả lời: chỉ admin ('reviews.delete').
require_permission('reviews.reply');
admin_require_csrf();
$me = current_user();
$active_nav = 'reviews';
$page_title = 'Đánh giá của khách';
$page_subtitle = 'Trả lời để khách thấy shop luôn lắng nghe. Phản hồi hiện công khai ở trang sản phẩm.';
$flash = '';
$error = '';

$canDelete = has_permission('reviews.delete');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'reply') {
        $reviewId = (int)($_POST['review_id'] ?? 0);
        $content = trim((string)($_POST['content'] ?? ''));
        $chk = $conn->prepare("SELECT id FROM reviews WHERE id = ?");
        $chk->bind_param('i', $reviewId);
        $chk->execute();
        if (!$chk->get_result()->fetch_assoc()) {
            $error = 'Đánh giá này không còn tồn tại.';
        } elseif ($content === '') {
            $error = 'Nội dung trả lời không được để trống.';
        } elseif (mb_strlen($content) > 1000) {
            $error = 'Nội dung trả lời tối đa 1000 ký tự.';
        } else {
            add_review_reply($conn, $reviewId, (int)$me['id'], $content);
            $flash = 'Đã gửi trả lời.';
            log_admin_action($conn, (int)$me['id'], 'review.reply', "review #$reviewId", mb_strimwidth($content, 0, 120, '…'));
        }
    } elseif ($action === 'delete_review' || $action === 'delete_reply') {
        if (!$canDelete) {
            http_response_code(403);
            $error = 'Chỉ quản trị viên mới được xoá đánh giá hoặc trả lời.';
        } elseif ($action === 'delete_review') {
            $reviewId = (int)($_POST['review_id'] ?? 0);
            $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
            $stmt->bind_param('i', $reviewId);
            $stmt->execute();
            $flash = 'Đã xoá đánh giá (kèm các lượt thích và trả lời của nó).';
            log_admin_action($conn, (int)$me['id'], 'review.delete', "review #$reviewId");
        } else {
            $replyId = (int)($_POST['reply_id'] ?? 0);
            $stmt = $conn->prepare("DELETE FROM review_replies WHERE id = ?");
            $stmt->bind_param('i', $replyId);
            $stmt->execute();
            $flash = 'Đã xoá trả lời.';
            log_admin_action($conn, (int)$me['id'], 'reply.delete', "reply #$replyId");
        }
    }
}

// ----- Lọc -----
$filter = ($_GET['filter'] ?? '') === 'pending' ? 'pending' : 'all';
$productId = (int)($_GET['product'] ?? 0);
$q = trim((string)($_GET['q'] ?? ''));

$pendingSql = "NOT EXISTS (SELECT 1 FROM review_replies rr JOIN users x ON rr.user_id = x.id
                           WHERE rr.review_id = r.id AND x.role IN ('admin','collaborator'))";
$where = [];
$types = '';
$params = [];
if ($filter === 'pending') $where[] = $pendingSql;
if ($productId > 0) { $where[] = 'r.product_id = ?'; $types .= 'i'; $params[] = $productId; }
if ($q !== '') {
    $where[] = '(r.content LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss'; array_push($params, $like, $like);
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$from = " FROM reviews r JOIN products p ON r.product_id = p.id JOIN users u ON r.user_id = u.id" . $whereSql;

$cnt = $conn->prepare("SELECT COUNT(*)" . $from);
if ($types !== '') $cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];

$allCount = (int)$conn->query("SELECT COUNT(*) FROM reviews")->fetch_row()[0];
$pendingCount = (int)$conn->query("SELECT COUNT(*) FROM reviews r WHERE $pendingSql")->fetch_row()[0];

$perPage = 10;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare(
    "SELECT r.id, r.content, r.created_at, p.id AS pid, p.name AS pname, u.username,
            (SELECT COUNT(*) FROM review_likes rl WHERE rl.review_id = r.id) AS likes"
    . $from . " ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?"
);
$stmt->bind_param($types . 'ii', ...array_merge($params, [$perPage, $pg['offset']]));
$stmt->execute();
$reviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$productList = $conn->query("SELECT DISTINCT p.id, p.name FROM products p JOIN reviews r ON r.product_id = p.id ORDER BY p.name")->fetch_all(MYSQLI_ASSOC);

$keep = ['filter' => $filter === 'pending' ? 'pending' : '', 'product' => $productId ?: '', 'q' => $q];

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="chips">
  <a class="chip<?php echo $filter === 'all' ? ' active' : ''; ?>" href="reviews.php">Tất cả<span class="n"><?php echo $allCount; ?></span></a>
  <a class="chip<?php echo $filter === 'pending' ? ' active' : ''; ?>" href="reviews.php?filter=pending">Chưa trả lời<span class="n"><?php echo $pendingCount; ?></span></a>
</div>

<div class="card">
  <form method="get" class="filters" style="margin-bottom:0;">
    <?php if ($filter === 'pending'): ?><input type="hidden" name="filter" value="pending"><?php endif; ?>
    <div class="grow"><label for="q">Tìm trong nội dung hoặc tên khách</label>
      <input type="search" id="q" name="q" value="<?php echo htmlspecialchars($q); ?>"></div>
    <div><label for="product">Sản phẩm</label>
      <select id="product" name="product">
        <option value="">Tất cả sản phẩm</option>
        <?php foreach ($productList as $pr): ?>
          <option value="<?php echo (int)$pr['id']; ?>" <?php echo $productId === (int)$pr['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($pr['name']); ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="shrink"><button type="submit" class="b">Lọc</button></div>
  </form>
</div>

<?php if (!$reviews): ?>
  <div class="card"><p class="empty" style="margin:0;"><?php echo $filter === 'pending' ? 'Không còn đánh giá nào chờ trả lời.' : 'Chưa có đánh giá nào khớp bộ lọc.'; ?></p></div>
<?php endif; ?>

<?php foreach ($reviews as $r):
    $rs = $conn->prepare("SELECT rr.id, rr.content, rr.created_at, u.username, u.role
                          FROM review_replies rr JOIN users u ON rr.user_id = u.id
                          WHERE rr.review_id = ? ORDER BY rr.created_at ASC, rr.id ASC");
    $rs->bind_param('i', $r['id']);
    $rs->execute();
    $replies = $rs->get_result()->fetch_all(MYSQLI_ASSOC);
    $hasStaffReply = false;
    foreach ($replies as $rep) { if (in_array($rep['role'], ['admin', 'collaborator'], true)) $hasStaffReply = true; }
?>
  <div class="rv<?php echo $hasStaffReply ? '' : ' pending'; ?>" id="review-<?php echo (int)$r['id']; ?>">
    <div class="rv-top">
      <span><strong style="color:var(--ink);"><?php echo htmlspecialchars($r['username']); ?></strong> về
        <a href="../product.php?id=<?php echo (int)$r['pid']; ?>#review-<?php echo (int)$r['id']; ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($r['pname']); ?></a></span>
      <span><?php echo (int)$r['likes']; ?> lượt thích · <?php echo htmlspecialchars($r['created_at']); ?>
        <?php if (!$hasStaffReply): ?> · <span class="tag warn">Chưa trả lời</span><?php endif; ?></span>
    </div>
    <?php /* Nội dung khách viết luôn được escape ở khu vực quản trị để mã độc (Stored XSS) không chạy được trên máy quản trị viên. */ ?>
    <div class="rv-body"><?php echo htmlspecialchars($r['content']); ?></div>

    <?php foreach ($replies as $rep): ?>
      <div class="rv-reply">
        <div class="who"><?php echo htmlspecialchars($rep['username']); ?> <?php echo staff_badge_html($rep['role']); ?> · <?php echo htmlspecialchars($rep['created_at']); ?></div>
        <?php echo htmlspecialchars($rep['content']); ?>
        <?php if ($canDelete): ?>
          <form method="post" style="display:inline;margin-left:8px;" onsubmit="return confirm('Xoá trả lời này?');">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="delete_reply">
            <input type="hidden" name="reply_id" value="<?php echo (int)$rep['id']; ?>">
            <button type="submit" class="link-btn">Xoá</button>
          </form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>

    <details <?php echo $hasStaffReply ? '' : 'open'; ?>>
      <summary>Viết trả lời</summary>
      <form method="post" action="reviews.php?<?php echo htmlspecialchars(http_build_query(array_filter($keep) + ($pg['page'] > 1 ? ['page' => $pg['page']] : []))); ?>#review-<?php echo (int)$r['id']; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="reply">
        <input type="hidden" name="review_id" value="<?php echo (int)$r['id']; ?>">
        <label for="reply-<?php echo (int)$r['id']; ?>">Trả lời với tên <?php echo htmlspecialchars($me['username']); ?> (<?php echo htmlspecialchars(role_label($me['role'])); ?>)</label>
        <textarea id="reply-<?php echo (int)$r['id']; ?>" name="content" maxlength="1000" required></textarea>
        <div class="form-actions"><button type="submit" class="b">Gửi trả lời</button></div>
      </form>
    </details>

    <?php if ($canDelete): ?>
      <form method="post" style="margin-top:10px;" onsubmit="return confirm('Xoá hẳn đánh giá này cùng mọi trả lời và lượt thích?');">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="delete_review">
        <input type="hidden" name="review_id" value="<?php echo (int)$r['id']; ?>">
        <button type="submit" class="b b-danger b-sm">Xoá đánh giá</button>
      </form>
    <?php endif; ?>
  </div>
<?php endforeach; ?>

<?php echo pagination_html($pg, $keep); ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
