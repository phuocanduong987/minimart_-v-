<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

require_permission('vouchers.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'vouchers';
$page_title = 'Mã giảm giá';
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $stmt = $conn->prepare("DELETE FROM vouchers WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $flash = 'Đã xoá voucher.';
        log_admin_action($conn, (int)$me['id'], 'voucher.delete', "#$id");
    } elseif ($action === 'toggle') {
        $stmt = $conn->prepare("UPDATE vouchers SET active = 1 - active WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $flash = 'Đã cập nhật trạng thái voucher.';
        log_admin_action($conn, (int)$me['id'], 'voucher.toggle', "#$id");
    } elseif ($action === 'create') {
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $description = trim($_POST['description'] ?? '');
        $type = ($_POST['discount_type'] ?? 'percent') === 'amount' ? 'amount' : 'percent';
        $value = (float)($_POST['discount_value'] ?? 0);
        $minOrder = (float)($_POST['min_order'] ?? 0);
        $maxUses = trim($_POST['max_uses'] ?? '');
        $maxUses = $maxUses === '' ? null : (int)$maxUses;
        $expires = trim($_POST['expires_at'] ?? '');
        $expires = $expires === '' ? null : $expires;

        if ($code === '' || $value <= 0) {
            $error = 'Vui lòng nhập mã voucher và giá trị giảm hợp lệ.';
        } elseif (!preg_match('/^[A-Z0-9_-]{3,30}$/', $code)) {
            $error = 'Mã voucher chỉ gồm chữ không dấu, số, gạch nối hoặc gạch dưới (3–30 ký tự).';
        } elseif ($type === 'percent' && $value > 100) {
            $error = 'Voucher phần trăm không được vượt quá 100%.';
        } else {
            try {
                $stmt = $conn->prepare(
                    "INSERT INTO vouchers (code, description, discount_type, discount_value, min_order, max_uses, expires_at)
                     VALUES (?,?,?,?,?,?,?)"
                );
                $stmt->bind_param('sssddis', $code, $description, $type, $value, $minOrder, $maxUses, $expires);
                $stmt->execute();
                $flash = 'Đã tạo voucher mới.';
                log_admin_action($conn, (int)$me['id'], 'voucher.create', $code);
            } catch (Throwable $e) {
                $error = 'Mã voucher đã tồn tại.';
            }
        }
    }
}

$vouchers = $conn->query("SELECT * FROM vouchers ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
$today = date('Y-m-d');
$page_subtitle = count($vouchers) . ' mã giảm giá';

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="adm-cols">
  <div class="card">
    <div class="tbl-wrap"><table>
      <tr><th>Mã</th><th>Giảm</th><th class="num">Đơn tối thiểu</th><th>Đã dùng</th><th>Hết hạn</th><th>Trạng thái</th><th></th></tr>
      <?php if (!$vouchers): ?><tr><td colspan="7" class="empty">Chưa có voucher nào. Tạo mã đầu tiên ở khung bên phải.</td></tr><?php endif; ?>
      <?php foreach ($vouchers as $v):
          $expired = $v['expires_at'] !== null && $v['expires_at'] < $today;
          $used = $v['max_uses'] !== null && (int)$v['used_count'] >= (int)$v['max_uses']; ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($v['code']); ?></strong><div class="muted"><?php echo htmlspecialchars($v['description'] ?? ''); ?></div></td>
          <td><?php echo $v['discount_type'] === 'percent' ? (float)$v['discount_value'] . '%' : vnd($v['discount_value']); ?></td>
          <td class="num"><?php echo vnd($v['min_order']); ?></td>
          <td><?php echo (int)$v['used_count'] . ($v['max_uses'] !== null ? ' / ' . (int)$v['max_uses'] : ''); ?></td>
          <td class="muted"><?php echo htmlspecialchars($v['expires_at'] ?? '—'); ?></td>
          <td>
            <?php if ($expired): ?><span class="tag bad">Hết hạn</span>
            <?php elseif ($used): ?><span class="tag warn">Hết lượt</span>
            <?php elseif ($v['active']): ?><span class="tag ok">Đang bật</span>
            <?php else: ?><span class="tag">Đã tắt</span><?php endif; ?>
          </td>
          <td>
            <div class="row-actions">
              <form method="post"><?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?php echo (int)$v['id']; ?>">
                <button type="submit" class="b b-ghost b-sm"><?php echo $v['active'] ? 'Tắt' : 'Bật'; ?></button></form>
              <form method="post" onsubmit="return confirm('Xoá voucher này?');"><?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$v['id']; ?>">
                <button type="submit" class="b b-danger b-sm">Xoá</button></form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="card">
    <h3>Thêm voucher mới</h3>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="create">
      <label for="code">Mã voucher</label>
      <input type="text" id="code" name="code" required style="text-transform:uppercase;" placeholder="VD: SALE20">

      <label for="description">Mô tả</label>
      <input type="text" id="description" name="description" placeholder="Hiển thị cho khách khi áp mã">

      <div class="form-grid">
        <div><label for="discount_type">Loại giảm</label>
          <select id="discount_type" name="discount_type">
            <option value="percent">Phần trăm (%)</option>
            <option value="amount">Số tiền (đ)</option>
          </select></div>
        <div><label for="discount_value">Giá trị giảm</label>
          <input type="number" id="discount_value" name="discount_value" min="0" step="0.01" required></div>
        <div><label for="min_order">Đơn tối thiểu (đ)</label>
          <input type="number" id="min_order" name="min_order" min="0" step="1000" value="0"></div>
        <div><label for="max_uses">Lượt dùng tối đa</label>
          <input type="number" id="max_uses" name="max_uses" min="1" placeholder="Không giới hạn"></div>
        <div class="full"><label for="expires_at">Ngày hết hạn</label>
          <input type="date" id="expires_at" name="expires_at"></div>
      </div>
      <div class="form-actions"><button type="submit" class="b">Tạo voucher</button></div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
