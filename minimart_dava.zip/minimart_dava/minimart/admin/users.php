<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

// Chỉ admin: đổi vai trò (nâng quyền lên cộng tác viên / hạ về khách), khoá, reset mật khẩu.
require_permission('users.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'users';
$page_title = 'Người dùng & phân quyền';
$page_subtitle = 'Nâng khách hàng lên cộng tác viên để họ quản lý sản phẩm và trả lời đánh giá.';
$flash = '';
$error = '';
$generated_password = null; // hiển thị 1 lần sau khi reset để admin gửi lại cho người dùng
$resetUsername = '';

$validRoles = ['admin', 'collaborator', 'customer'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    $t = $conn->prepare("SELECT id, username, role, is_locked FROM users WHERE id = ?");
    $t->bind_param('i', $id);
    $t->execute();
    $target = $t->get_result()->fetch_assoc();

    if (!$target) {
        $error = 'Không tìm thấy người dùng này.';
    } elseif ($id === (int)$me['id']) {
        // Không cho tự đổi quyền / tự khoá / tự reset chính mình để tránh vô tình mất quyền quản trị.
        $error = 'Không thể thực hiện thao tác này trên chính tài khoản đang đăng nhập.';
    } elseif ($action === 'set_role') {
        $newRole = (string)($_POST['role'] ?? '');
        if (!in_array($newRole, $validRoles, true)) {
            $error = 'Vai trò không hợp lệ.';
        } elseif ($newRole === $target['role']) {
            $flash = 'Vai trò không thay đổi.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->bind_param('si', $newRole, $id);
            $stmt->execute();
            $flash = 'Đã đổi vai trò của ' . $target['username'] . ' thành ' . role_label($newRole) . '.';
            log_admin_action($conn, (int)$me['id'], 'user.role', $target['username'], role_label($target['role']) . ' → ' . role_label($newRole));
        }
    } elseif ($action === 'lock') {
        $stmt = $conn->prepare("UPDATE users SET is_locked = 1, locked_at = NOW() WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $flash = 'Đã khoá tài khoản.';
        log_admin_action($conn, (int)$me['id'], 'user.lock', $target['username']);
    } elseif ($action === 'unlock') {
        $stmt = $conn->prepare("UPDATE users SET is_locked = 0, locked_at = NULL WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $flash = 'Đã mở khoá tài khoản.';
        log_admin_action($conn, (int)$me['id'], 'user.unlock', $target['username']);
    } elseif ($action === 'clear_attempts') {
        // Mở khoá đăng nhập: xoá lịch sử đăng nhập sai của tài khoản này (khác với is_locked do admin chủ động khoá).
        $stmt = $conn->prepare("DELETE FROM login_attempts WHERE username = ?");
        $stmt->bind_param('s', $target['username']);
        $stmt->execute();
        $flash = 'Đã mở khoá đăng nhập cho ' . $target['username'] . ' (xoá ' . $stmt->affected_rows . ' lần thử sai).';
        log_admin_action($conn, (int)$me['id'], 'user.clear_attempts', $target['username']);
    } elseif ($action === 'reset_password') {
        $new_password = bin2hex(random_bytes(4));
        $hashed = hash_password($new_password);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $hashed, $id);
        $stmt->execute();
        revoke_user_sessions($conn, (int)$target['id'], false); // mật khẩu đổi -> mọi phiên cũ của người đó mất hiệu lực
        $clr = $conn->prepare("DELETE FROM login_attempts WHERE username = ?");
        $clr->bind_param('s', $target['username']);
        $clr->execute();
        $generated_password = $new_password;
        $resetUsername = $target['username'];
        $flash = 'Đã đặt lại mật khẩu. Hãy gửi mật khẩu mới bên dưới cho người dùng (chỉ hiển thị 1 lần).';
        log_admin_action($conn, (int)$me['id'], 'user.reset_password', $target['username']);
    }
}

// ----- Lọc -----
$roleFilter = (string)($_GET['role'] ?? '');
if (!in_array($roleFilter, $validRoles, true)) $roleFilter = '';
$q = trim((string)($_GET['q'] ?? ''));
$where = [];
$types = '';
$params = [];
if ($roleFilter !== '') { $where[] = 'role = ?'; $types .= 's'; $params[] = $roleFilter; }
if ($q !== '') {
    $where[] = '(username LIKE ? OR email LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss'; array_push($params, $like, $like);
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$cnt = $conn->prepare("SELECT COUNT(*) FROM users" . $whereSql);
if ($types !== '') $cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];
$perPage = 15;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare("SELECT id, username, email, role, is_locked, created_at FROM users" . $whereSql . " ORDER BY FIELD(role,'admin','collaborator','customer'), id LIMIT ? OFFSET ?");
$stmt->bind_param($types . 'ii', ...array_merge($params, [$perPage, $pg['offset']]));
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Lần đăng nhập sai trong 15 phút gần nhất của từng tài khoản, kèm số giây còn lại trước khi từng lần "hết hạn".
// Tính bằng giờ của MySQL (TIMESTAMPDIFF) nên không bị lệch múi giờ giữa PHP và DB.
$recentFails = [];   // username => số lần sai
$unlockIn = [];      // username => số giây nữa được đăng nhập lại (chỉ có khi đã bị khoá tạm)
$byUser = [];
$rs = $conn->query("SELECT username,
                           GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), created_at + INTERVAL 15 MINUTE)) AS secs_left
                    FROM login_attempts
                    WHERE created_at > (NOW() - INTERVAL 15 MINUTE)
                    ORDER BY username, created_at ASC");
foreach ($rs as $r) { $byUser[$r['username']][] = (int)$r['secs_left']; }
foreach ($byUser as $name => $list) {
    $n = count($list);
    $recentFails[$name] = $n;
    // Khoá khi có >= 5 lần sai; mở lại khi lần sai thứ (n-4) tính từ cũ nhất hết hạn (phần tử chỉ số n-5).
    if ($n >= 5) { $unlockIn[$name] = $list[$n - 5]; }
}

/** 754 giây -> "12 phút 34 giây" */
function fmt_remaining(int $sec): string {
    if ($sec <= 0) return 'dưới 1 giây';
    $m = intdiv($sec, 60); $s = $sec % 60;
    return trim(($m > 0 ? $m . ' phút ' : '') . ($s > 0 || $m === 0 ? $s . ' giây' : ''));
}

$roleCounts = ['admin' => 0, 'collaborator' => 0, 'customer' => 0];
foreach ($conn->query("SELECT role, COUNT(*) c FROM users GROUP BY role") as $r) $roleCounts[$r['role']] = (int)$r['c'];

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
if ($generated_password !== null): ?>
  <div class="flash ok">
    Mật khẩu mới cho <strong><?php echo htmlspecialchars($resetUsername); ?></strong>:
    <code class="pw"><?php echo htmlspecialchars($generated_password); ?></code>
    — sẽ không hiển thị lại, hãy gửi cho người dùng ngay bây giờ.
  </div>
<?php endif; ?>

<div class="chips">
  <a class="chip<?php echo $roleFilter === '' ? ' active' : ''; ?>" href="users.php">Tất cả<span class="n"><?php echo array_sum($roleCounts); ?></span></a>
  <?php foreach ($validRoles as $rk): ?>
    <a class="chip<?php echo $roleFilter === $rk ? ' active' : ''; ?>" href="users.php?role=<?php echo $rk; ?>"><?php echo htmlspecialchars(role_label($rk)); ?><span class="n"><?php echo $roleCounts[$rk]; ?></span></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <form method="get" class="filters">
    <?php if ($roleFilter !== ''): ?><input type="hidden" name="role" value="<?php echo htmlspecialchars($roleFilter); ?>"><?php endif; ?>
    <div class="grow"><label for="q">Tìm người dùng</label>
      <input type="search" id="q" name="q" placeholder="Tên đăng nhập hoặc email" value="<?php echo htmlspecialchars($q); ?>"></div>
    <div class="shrink"><button type="submit" class="b">Tìm</button></div>
  </form>

  <div class="tbl-wrap"><table>
    <tr><th>Tài khoản</th><th>Vai trò</th><th>Trạng thái</th><th>Ngày tạo</th><th>Thao tác</th></tr>
    <?php if (!$users): ?><tr><td colspan="5" class="empty">Không có người dùng nào khớp.</td></tr><?php endif; ?>
    <?php foreach ($users as $u): $isSelf = (int)$u['id'] === (int)$me['id']; ?>
      <tr>
        <td><strong><?php echo htmlspecialchars($u['username']); ?></strong><div class="muted"><?php echo htmlspecialchars($u['email']); ?></div></td>
        <td><span class="tag role-<?php echo htmlspecialchars($u['role']); ?>"><?php echo htmlspecialchars(role_label($u['role'])); ?></span></td>
        <td><?php echo (int)$u['is_locked'] === 1 ? '<span class="tag bad">Đã khoá</span>' : '<span class="tag ok">Hoạt động</span>'; ?>
          <?php $f = $recentFails[$u['username']] ?? 0; if ($f >= 5): $left = (int)($unlockIn[$u['username']] ?? 0); ?>
            <div><span class="tag bad">Khoá đăng nhập tạm (<?php echo $f; ?> lần sai)</span></div>
            <div class="muted">Mở lại lúc <strong><?php echo htmlspecialchars(date('H:i:s d/m', time() + $left)); ?></strong>
              (còn <?php echo htmlspecialchars(fmt_remaining($left)); ?>)</div>
          <?php elseif ($f > 0): ?>
            <div class="muted"><?php echo $f; ?> lần đăng nhập sai</div>
          <?php endif; ?></td>
        <td class="muted"><?php echo htmlspecialchars($u['created_at']); ?></td>
        <td>
          <?php if ($isSelf): ?>
            <span class="muted">Tài khoản của bạn</span>
          <?php else: ?>
            <div class="row-actions">
              <form method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="set_role">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <select name="role" style="width:auto;padding:5px 8px;" aria-label="Vai trò của <?php echo htmlspecialchars($u['username']); ?>">
                  <?php foreach ($validRoles as $rk): ?>
                    <option value="<?php echo $rk; ?>" <?php echo $u['role'] === $rk ? 'selected' : ''; ?>><?php echo htmlspecialchars(role_label($rk)); ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" class="b b-ghost b-sm" onclick="return confirm('Đổi vai trò của <?php echo htmlspecialchars(addslashes($u['username'])); ?>?');">Đổi quyền</button>
              </form>
              <form method="post" onsubmit="return confirm('Đặt lại mật khẩu cho <?php echo htmlspecialchars(addslashes($u['username'])); ?>?');">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <button type="submit" class="b b-ghost b-sm">Reset mật khẩu</button>
              </form>
              <?php if (($recentFails[$u['username']] ?? 0) > 0): ?>
              <form method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="clear_attempts">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <button type="submit" class="b b-ghost b-sm">Mở khoá đăng nhập</button>
              </form>
              <?php endif; ?>
              <form method="post" <?php echo (int)$u['is_locked'] === 1 ? '' : 'onsubmit="return confirm(\'Khoá tài khoản ' . htmlspecialchars(addslashes($u['username'])) . '? Người này sẽ không đăng nhập được nữa.\');"'; ?>>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="<?php echo (int)$u['is_locked'] === 1 ? 'unlock' : 'lock'; ?>">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <button type="submit" class="b <?php echo (int)$u['is_locked'] === 1 ? 'b-ghost' : 'b-danger'; ?> b-sm"><?php echo (int)$u['is_locked'] === 1 ? 'Mở khoá' : 'Khoá'; ?></button>
              </form>
            </div>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php echo pagination_html($pg, ['role' => $roleFilter, 'q' => $q]); ?>
</div>

<div class="card">
  <h3>Mỗi vai trò làm được gì</h3>
  <div class="tbl-wrap"><table>
    <tr><th>Chức năng</th><th>Quản trị viên</th><th>Cộng tác viên</th><th>Khách hàng</th></tr>
    <?php
    $matrix = [
        ['Xem bảng điều khiển (cộng tác viên chỉ thấy số liệu sản phẩm, đánh giá)', 1, 1, 0],
        ['Thêm, sửa sản phẩm, cập nhật tồn kho', 1, 1, 0],
        ['Trả lời đánh giá của khách', 1, 1, 0],
        ['Xoá sản phẩm, xoá đánh giá và trả lời', 1, 0, 0],
        ['Quản lý đơn hàng, xuất CSV', 1, 0, 0],
        ['Quản lý mã giảm giá', 1, 0, 0],
        ['Quản lý người dùng, đổi vai trò, xem nhật ký', 1, 0, 0],
        ['Mua hàng trên cửa hàng', 0, 0, 1],
    ];
    foreach ($matrix as $row): ?>
      <tr><td><?php echo htmlspecialchars($row[0]); ?></td>
        <?php for ($i = 1; $i <= 3; $i++): ?><td><?php echo $row[$i] ? '<span class="tag ok">Có</span>' : '<span class="muted">—</span>'; ?></td><?php endfor; ?></tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
