<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

require_permission('logs.view');
$me = current_user();
$active_nav = 'logs';
$page_title = 'Nhật ký thao tác';
$page_subtitle = 'Ai đã làm gì trong khu vực quản trị — hữu ích để kiểm tra hoạt động của cộng tác viên.';

$labels = [
    'product.create' => 'Thêm sản phẩm', 'product.update' => 'Sửa sản phẩm', 'product.stock' => 'Đổi tồn kho', 'product.delete' => 'Xoá sản phẩm',
    'review.reply' => 'Trả lời đánh giá', 'review.delete' => 'Xoá đánh giá', 'reply.delete' => 'Xoá trả lời',
    'order.status' => 'Đổi trạng thái đơn', 'order.export' => 'Xuất đơn hàng',
    'voucher.create' => 'Tạo voucher', 'voucher.toggle' => 'Bật/tắt voucher', 'voucher.delete' => 'Xoá voucher',
    'payout.request' => 'CTV yêu cầu rút tiền', 'payout.cancel' => 'CTV huỷ yêu cầu rút', 'payout.approve' => 'Duyệt chi hoa hồng', 'payout.reject' => 'Từ chối rút tiền', 'ctv.rate' => 'Đổi tỷ lệ hoa hồng',
    'user.role' => 'Đổi vai trò', 'user.clear_attempts' => 'Mở khoá đăng nhập', 'user.lock' => 'Khoá tài khoản', 'user.unlock' => 'Mở khoá tài khoản', 'user.reset_password' => 'Reset mật khẩu',
];

$actionFilter = (string)($_GET['action'] ?? '');
$userFilter = (int)($_GET['user'] ?? 0);
$where = [];
$types = '';
$params = [];
if ($actionFilter !== '' && isset($labels[$actionFilter])) { $where[] = 'l.action = ?'; $types .= 's'; $params[] = $actionFilter; }
if ($userFilter > 0) { $where[] = 'l.user_id = ?'; $types .= 'i'; $params[] = $userFilter; }
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$rows = [];
$total = 0;
$pg = paginate(0, 30, 1);
$staff = [];
$missingTable = false;
try {
    $cnt = $conn->prepare("SELECT COUNT(*) FROM admin_logs l" . $whereSql);
    if ($types !== '') $cnt->bind_param($types, ...$params);
    $cnt->execute();
    $total = (int)$cnt->get_result()->fetch_row()[0];
    $pg = paginate($total, 30, (int)($_GET['page'] ?? 1));
    $stmt = $conn->prepare("SELECT l.*, u.username, u.role FROM admin_logs l JOIN users u ON l.user_id = u.id" . $whereSql . " ORDER BY l.id DESC LIMIT ? OFFSET ?");
    $stmt->bind_param($types . 'ii', ...array_merge($params, [30, $pg['offset']]));
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $staff = $conn->query("SELECT id, username FROM users WHERE role IN ('admin','collaborator') ORDER BY username")->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    $missingTable = true;
}

require __DIR__ . '/../includes/admin_header.php';
if ($missingTable): ?>
  <div class="flash error">Chưa có bảng nhật ký. Hãy chạy <code>sql/add_roles_admin_migration.sql</code> (hoặc import lại <code>reset_database.sql</code>).</div>
<?php else: ?>
  <div class="card">
    <form method="get" class="filters">
      <div><label for="user">Người thực hiện</label>
        <select id="user" name="user">
          <option value="">Tất cả</option>
          <?php foreach ($staff as $s): ?>
            <option value="<?php echo (int)$s['id']; ?>" <?php echo $userFilter === (int)$s['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['username']); ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label for="action">Loại thao tác</label>
        <select id="action" name="action">
          <option value="">Tất cả</option>
          <?php foreach ($labels as $k => $lbl): ?>
            <option value="<?php echo $k; ?>" <?php echo $actionFilter === $k ? 'selected' : ''; ?>><?php echo htmlspecialchars($lbl); ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="shrink"><button type="submit" class="b">Lọc</button></div>
    </form>

    <div class="tbl-wrap"><table>
      <tr><th>Thời gian</th><th>Người thực hiện</th><th>Thao tác</th><th>Đối tượng</th><th>Chi tiết</th><th>IP</th></tr>
      <?php if (!$rows): ?><tr><td colspan="6" class="empty">Chưa có thao tác nào được ghi lại.</td></tr><?php endif; ?>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="muted"><?php echo htmlspecialchars($r['created_at']); ?></td>
          <td><?php echo htmlspecialchars($r['username']); ?> <span class="tag role-<?php echo htmlspecialchars($r['role']); ?>"><?php echo htmlspecialchars(role_label($r['role'])); ?></span></td>
          <td><?php echo htmlspecialchars($labels[$r['action']] ?? $r['action']); ?></td>
          <td><?php echo htmlspecialchars($r['target'] ?? ''); ?></td>
          <td class="muted"><?php echo htmlspecialchars($r['detail'] ?? ''); ?></td>
          <td class="muted"><?php echo htmlspecialchars($r['ip'] ?? ''); ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php echo pagination_html($pg, ['action' => $actionFilter, 'user' => $userFilter ?: '']); ?>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
