<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

// Admin và cộng tác viên cùng có quyền này. Xoá sản phẩm là quyền riêng 'products.delete' (chỉ admin).
require_permission('products.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'products';
$page_title = 'Sản phẩm';
$flash = '';
$error = '';

$tree = category_tree();
$low = low_stock_threshold();

function product_form_errors(array $d): string {
    if (trim($d['name']) === '') return 'Vui lòng nhập tên sản phẩm.';
    if (!is_numeric($d['price']) || (float)$d['price'] < 0) return 'Giá sản phẩm không hợp lệ.';
    if (!ctype_digit((string)$d['stock'])) return 'Tồn kho phải là số nguyên không âm.';
    return '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        if (!has_permission('products.delete')) {
            http_response_code(403);
            $error = 'Chỉ quản trị viên mới được xoá sản phẩm. Bạn có thể đặt tồn kho về 0 để ngừng bán.';
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $nameStmt = $conn->prepare("SELECT name FROM products WHERE id = ?");
            $nameStmt->bind_param('i', $id);
            $nameStmt->execute();
            $pname = $nameStmt->get_result()->fetch_assoc()['name'] ?? '';
            try {
                $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
                $stmt->bind_param('i', $id);
                $stmt->execute();
                $flash = 'Đã xoá sản phẩm.';
                log_admin_action($conn, (int)$me['id'], 'product.delete', "#$id", $pname);
            } catch (Throwable $e) {
                // Thường do sản phẩm đã có trong order_items/reviews (ràng buộc khoá ngoại).
                $error = 'Không thể xoá sản phẩm này vì đã có đơn hàng hoặc đánh giá liên quan. Bạn có thể đặt tồn kho về 0 để ngừng bán.';
            }
        }
    } elseif ($action === 'quick_stock') {
        $id = (int)($_POST['id'] ?? 0);
        $stock = $_POST['stock'] ?? '';
        if (!ctype_digit((string)$stock)) {
            $error = 'Tồn kho phải là số nguyên không âm.';
        } else {
            $stock = (int)$stock;
            $stmt = $conn->prepare("UPDATE products SET stock = ? WHERE id = ?");
            $stmt->bind_param('ii', $stock, $id);
            $stmt->execute();
            $flash = 'Đã cập nhật tồn kho.';
            log_admin_action($conn, (int)$me['id'], 'product.stock', "#$id", "Tồn kho = $stock");
        }
    } elseif ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price = $_POST['price'] ?? '0';
        $stock = $_POST['stock'] ?? '0';
        $category = $_POST['category'] ?? '';
        $subcategory = $_POST['subcategory'] ?? '';

        $err = product_form_errors(['name' => $name, 'price' => $price, 'stock' => $stock]);
        if (!isset($tree[$category])) { $category = null; $subcategory = null; }
        elseif (!isset($tree[$category]['subs'][$subcategory])) { $subcategory = null; }

        if ($err !== '') {
            $error = $err;
        } elseif ($id > 0) {
            $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category=?, subcategory=? WHERE id=?");
            $stmt->bind_param('ssdissi', $name, $description, $price, $stock, $category, $subcategory, $id);
            $stmt->execute();
            $flash = 'Đã cập nhật sản phẩm.';
            log_admin_action($conn, (int)$me['id'], 'product.update', "#$id", $name);
        } else {
            $stmt = $conn->prepare("INSERT INTO products (name, description, price, stock, category, subcategory) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('ssdiss', $name, $description, $price, $stock, $category, $subcategory);
            $stmt->execute();
            $flash = 'Đã thêm sản phẩm mới.';
            log_admin_action($conn, (int)$me['id'], 'product.create', '#' . $stmt->insert_id, $name);
        }
    }
}

// ----- Sản phẩm đang sửa -----
$editId = (int)($_GET['edit'] ?? 0);
$editProduct = null;
if ($editId > 0) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param('i', $editId);
    $stmt->execute();
    $editProduct = $stmt->get_result()->fetch_assoc();
}

// ----- Tìm kiếm / lọc -----
$q = trim((string)($_GET['q'] ?? ''));
$cat = (string)($_GET['cat'] ?? '');
$stockFilter = (string)($_GET['stock'] ?? '');
$where = [];
$types = '';
$params = [];
if ($q !== '') {
    $where[] = "(name LIKE ? OR description LIKE ?)";
    $like = '%' . $q . '%';
    $types .= 'ss'; array_push($params, $like, $like);
}
if ($cat !== '' && isset($tree[$cat])) {
    $where[] = "category = ?";
    $types .= 's'; $params[] = $cat;
}
if ($stockFilter === 'out') {
    $where[] = "stock = 0";
} elseif ($stockFilter === 'low') {
    $where[] = "stock <= ?";
    $types .= 'i'; $params[] = $low;
}
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$cnt = $conn->prepare("SELECT COUNT(*) FROM products" . $whereSql);
if ($types !== '') $cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];

$perPage = 12;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare("SELECT * FROM products" . $whereSql . " ORDER BY id DESC LIMIT ? OFFSET ?");
$bindTypes = $types . 'ii';
$bindParams = array_merge($params, [$perPage, $pg['offset']]);
$stmt->bind_param($bindTypes, ...$bindParams);
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$canDelete = has_permission('products.delete');
$page_subtitle = $total . ' sản phẩm' . (($q !== '' || $cat !== '' || $stockFilter !== '') ? ' phù hợp bộ lọc' : '');
$head_actions = $editProduct ? '<a class="b" href="products.php">+ Thêm sản phẩm mới</a>' : '';

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="adm-cols">
  <div class="card">
    <form method="get" class="filters">
      <div class="grow"><label for="q">Tìm sản phẩm</label>
        <input type="search" id="q" name="q" placeholder="Tên hoặc mô tả" value="<?php echo htmlspecialchars($q); ?>"></div>
      <div><label for="cat">Danh mục</label>
        <select id="cat" name="cat">
          <option value="">Tất cả</option>
          <?php foreach ($tree as $k => $info): ?>
            <option value="<?php echo htmlspecialchars($k); ?>" <?php echo $cat === $k ? 'selected' : ''; ?>><?php echo htmlspecialchars($info['label']); ?></option>
          <?php endforeach; ?>
        </select></div>
      <div><label for="stock">Tồn kho</label>
        <select id="stock" name="stock">
          <option value="">Tất cả</option>
          <option value="low" <?php echo $stockFilter === 'low' ? 'selected' : ''; ?>>Sắp hết (≤ <?php echo $low; ?>)</option>
          <option value="out" <?php echo $stockFilter === 'out' ? 'selected' : ''; ?>>Hết hàng</option>
        </select></div>
      <div class="shrink"><button type="submit" class="b">Lọc</button>
        <?php if ($q !== '' || $cat !== '' || $stockFilter !== ''): ?><a class="b b-ghost" href="products.php">Xoá lọc</a><?php endif; ?></div>
    </form>

    <div class="tbl-wrap"><table>
      <tr><th>Sản phẩm</th><th class="num">Giá</th><th>Tồn kho</th><th>Danh mục</th><th></th></tr>
      <?php if (!$products): ?>
        <tr><td colspan="5" class="empty">Không có sản phẩm nào. Thử bỏ bớt bộ lọc hoặc thêm sản phẩm mới.</td></tr>
      <?php endif; ?>
      <?php foreach ($products as $p): ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($p['name']); ?></strong><div class="muted">#<?php echo (int)$p['id']; ?></div></td>
          <td class="num"><?php echo vnd($p['price']); ?></td>
          <td>
            <form method="post" class="row-actions">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="action" value="quick_stock">
              <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
              <input type="number" name="stock" min="0" value="<?php echo (int)$p['stock']; ?>" style="width:72px;padding:5px 8px;" aria-label="Tồn kho sản phẩm #<?php echo (int)$p['id']; ?>">
              <?php if ((int)$p['stock'] === 0): ?><span class="tag bad">Hết</span>
              <?php elseif ((int)$p['stock'] <= $low): ?><span class="tag warn">Sắp hết</span><?php endif; ?>
              <button type="submit" class="b b-ghost b-sm">Lưu</button>
            </form>
          </td>
          <td class="muted"><?php echo htmlspecialchars(($tree[$p['category']]['label'] ?? $p['category']) ?: '—'); ?></td>
          <td>
            <div class="row-actions">
              <a class="b b-ghost b-sm" href="?<?php echo htmlspecialchars(http_build_query(array_filter(['q' => $q, 'cat' => $cat, 'stock' => $stockFilter, 'page' => $pg['page'] > 1 ? $pg['page'] : null, 'edit' => $p['id']]))); ?>">Sửa</a>
              <?php if ($canDelete): ?>
                <form method="post" onsubmit="return confirm('Xoá sản phẩm này?');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                  <button type="submit" class="b b-danger b-sm">Xoá</button>
                </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php echo pagination_html($pg, ['q' => $q, 'cat' => $cat, 'stock' => $stockFilter]); ?>
    <?php if (!$canDelete): ?><p class="hint" style="margin-top:12px;">Bạn là cộng tác viên nên chỉ thêm và sửa được sản phẩm. Muốn ngừng bán, hãy đặt tồn kho về 0.</p><?php endif; ?>
  </div>

  <div class="card" id="product-form">
    <h3><?php echo $editProduct ? 'Sửa sản phẩm #' . (int)$editProduct['id'] : 'Thêm sản phẩm mới'; ?></h3>
    <form method="post" action="products.php<?php echo $editProduct ? '?edit=' . (int)$editProduct['id'] : ''; ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?php echo (int)($editProduct['id'] ?? 0); ?>">

      <label for="name">Tên sản phẩm</label>
      <input type="text" id="name" name="name" required value="<?php echo htmlspecialchars($editProduct['name'] ?? ''); ?>">

      <label for="description">Mô tả</label>
      <textarea id="description" name="description"><?php echo htmlspecialchars($editProduct['description'] ?? ''); ?></textarea>

      <div class="form-grid">
        <div><label for="price">Giá (đ)</label>
          <input type="number" id="price" name="price" min="0" step="1000" required value="<?php echo htmlspecialchars((string)($editProduct['price'] ?? 0)); ?>"></div>
        <div><label for="pstock">Tồn kho</label>
          <input type="number" id="pstock" name="stock" min="0" required value="<?php echo htmlspecialchars((string)($editProduct['stock'] ?? 0)); ?>"></div>
      </div>

      <label for="category">Danh mục</label>
      <select id="category" name="category">
        <option value="">— Chọn danh mục —</option>
        <?php foreach ($tree as $catKey => $catInfo): ?>
          <option value="<?php echo htmlspecialchars($catKey); ?>" <?php echo (($editProduct['category'] ?? '') === $catKey) ? 'selected' : ''; ?>><?php echo htmlspecialchars($catInfo['label']); ?></option>
        <?php endforeach; ?>
      </select>

      <label for="subcategory">Danh mục con</label>
      <select id="subcategory" name="subcategory">
        <option value="">— Không có —</option>
        <?php foreach ($tree as $catKey => $catInfo): foreach ($catInfo['subs'] as $subKey => $subLabel): ?>
          <option value="<?php echo htmlspecialchars($subKey); ?>" data-parent="<?php echo htmlspecialchars($catKey); ?>"
            <?php echo (($editProduct['subcategory'] ?? '') === $subKey) ? 'selected' : ''; ?>><?php echo htmlspecialchars($subLabel); ?></option>
        <?php endforeach; endforeach; ?>
      </select>
      <div class="hint">Chỉ hiện danh mục con thuộc danh mục cha đã chọn.</div>

      <div class="form-actions">
        <button type="submit" class="b"><?php echo $editProduct ? 'Lưu thay đổi' : 'Thêm sản phẩm'; ?></button>
        <?php if ($editProduct): ?><a class="b b-ghost" href="products.php">Huỷ sửa</a><?php endif; ?>
      </div>
    </form>
  </div>
</div>

<script>
// Lọc danh mục con theo danh mục cha đang chọn.
(function () {
  var cat = document.getElementById('category');
  var sub = document.getElementById('subcategory');
  if (!cat || !sub) return;
  function sync() {
    var parent = cat.value;
    Array.prototype.forEach.call(sub.options, function (o) {
      if (!o.dataset.parent) return;
      var show = o.dataset.parent === parent;
      o.hidden = !show; o.disabled = !show;
      if (!show && o.selected) sub.value = '';
    });
  }
  cat.addEventListener('change', function () { sub.value = ''; sync(); });
  sync();
})();
</script>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
