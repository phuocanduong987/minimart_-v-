<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

require_permission('orders.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'orders';
$flash = '';
$error = '';

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $newStatus = (string)($_POST['status'] ?? '');
    $result = update_order_status($conn, $id, $newStatus);
    if ($result['ok']) {
        $flash = 'Đã cập nhật trạng thái đơn #' . $id . '.';
        log_admin_action($conn, (int)$me['id'], 'order.status', "#$id", "→ $newStatus");
    } else {
        $error = $result['message'];
    }
}

$stmt = $conn->prepare("SELECT o.*, u.username, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    http_response_code(404);
    $page_title = 'Không tìm thấy đơn hàng';
    $page_subtitle = 'Đơn #' . $id . ' không tồn tại.';
    $head_actions = '<a class="b b-ghost" href="orders.php">Về danh sách đơn</a>';
    require __DIR__ . '/../includes/admin_header.php';
    require __DIR__ . '/../includes/admin_footer.php';
    exit;
}

$it = $conn->prepare("SELECT p.id, p.name, oi.quantity, oi.price FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$it->bind_param('i', $id);
$it->execute();
$items = $it->get_result()->fetch_all(MYSQLI_ASSOC);
$subtotal = 0.0;
foreach ($items as $row) $subtotal += $row['quantity'] * $row['price'];

$statusList = order_status_list();
$page_title = 'Đơn hàng #' . $order['id'];
$page_subtitle = 'Đặt lúc ' . $order['created_at'] . ' bởi ' . $order['username'];
$head_actions = '<a class="b b-ghost" href="orders.php">← Danh sách đơn</a>';

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="adm-cols">
  <div class="card">
    <h3>Sản phẩm trong đơn</h3>
    <div class="tbl-wrap"><table>
      <tr><th>Sản phẩm</th><th class="num">Đơn giá</th><th class="num">SL</th><th class="num">Thành tiền</th></tr>
      <?php foreach ($items as $row): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['name']); ?></td>
          <td class="num"><?php echo vnd($row['price']); ?></td>
          <td class="num"><?php echo (int)$row['quantity']; ?></td>
          <td class="num"><?php echo vnd($row['quantity'] * $row['price']); ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <div style="max-width:320px;margin-left:auto;margin-top:14px;">
      <div class="sum-row"><span>Tạm tính</span><span><?php echo vnd($subtotal); ?></span></div>
      <div class="sum-row"><span>Phí vận chuyển</span><span><?php echo vnd($order['shipping_fee']); ?></span></div>
      <div class="sum-row"><span>Giảm giá<?php echo $order['voucher_code'] ? ' (' . htmlspecialchars($order['voucher_code']) . ')' : ''; ?></span><span>−<?php echo vnd($order['discount_amount']); ?></span></div>
      <div class="sum-row total"><span>Tổng thanh toán</span><span><?php echo vnd($order['total']); ?></span></div>
    </div>
  </div>

  <div>
    <div class="card">
      <h3>Trạng thái</h3>
      <p><span class="tag <?php echo order_status_tone($order['status']); ?>"><?php echo htmlspecialchars($order['status']); ?></span></p>
      <form method="post" action="order_view.php?id=<?php echo (int)$order['id']; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_status">
        <label for="status">Đổi sang</label>
        <select id="status" name="status">
          <?php foreach ($statusList as $s): ?>
            <option value="<?php echo htmlspecialchars($s); ?>" <?php echo $order['status'] === $s ? 'selected' : ''; ?>><?php echo htmlspecialchars($s); ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Chuyển sang “Đã hủy” hoặc “Đã hoàn hàng” sẽ tự cộng lại tồn kho.</div>
        <div class="form-actions"><button type="submit" class="b">Cập nhật</button></div>
      </form>
    </div>
    <div class="card">
      <h3>Khách hàng &amp; giao hàng</h3>
      <dl class="kv">
        <dt>Tài khoản</dt><dd><?php echo htmlspecialchars($order['username']); ?></dd>
        <dt>Email</dt><dd><?php echo htmlspecialchars($order['email']); ?></dd>
        <dt>Điện thoại</dt><dd><?php echo htmlspecialchars($order['phone'] ?? '—'); ?></dd>
        <dt>Địa chỉ</dt><dd><?php echo htmlspecialchars($order['address'] ?? '—'); ?></dd>
      </dl>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
