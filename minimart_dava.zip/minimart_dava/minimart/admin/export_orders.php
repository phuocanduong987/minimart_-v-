<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/admin_orders_query.php';

require_permission('orders.manage');
$me = current_user();

[$whereSql, $types, $params] = admin_orders_filter(order_status_list(), $_GET);
$stmt = $conn->prepare(
    "SELECT o.id, u.username, o.total, o.shipping_fee, o.discount_amount, o.voucher_code, o.status, o.phone, o.address, o.created_at
     FROM orders o JOIN users u ON o.user_id = u.id" . $whereSql . " ORDER BY o.id DESC"
);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result();

log_admin_action($conn, (int)$me['id'], 'order.export', 'CSV', $rows->num_rows . ' đơn');

/** Chống CSV injection: ô bắt đầu bằng = + - @ sẽ bị Excel hiểu là công thức. */
function csv_safe($v): string {
    $v = (string)$v;
    return ($v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) ? "'" . $v : $v;
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="don-hang-' . date('Ymd-His') . '.csv"');
echo "\xEF\xBB\xBF"; // BOM để Excel mở đúng tiếng Việt
$out = fopen('php://output', 'w');
fputcsv($out, ['Mã đơn', 'Khách hàng', 'Tổng tiền', 'Phí ship', 'Giảm giá', 'Voucher', 'Trạng thái', 'SĐT', 'Địa chỉ', 'Ngày tạo']);
foreach ($rows as $r) {
    fputcsv($out, [
        $r['id'], csv_safe($r['username']), (float)$r['total'], (float)$r['shipping_fee'], (float)$r['discount_amount'],
        csv_safe($r['voucher_code'] ?? ''), csv_safe($r['status']), csv_safe($r['phone'] ?? ''), csv_safe($r['address'] ?? ''), $r['created_at'],
    ]);
}
fclose($out);
