<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/admin_orders_query.php';

require_permission('orders.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'orders';
$page_title = 'Đơn hàng';
$flash = '';
$error = '';

$statusList = order_status_list();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $orderId = (int)($_POST['order_id'] ?? 0);
    $newStatus = (string)($_POST['status'] ?? '');
    if ($orderId > 0) {
        // update_order_status() tự cộng/trừ lại tồn kho khi đơn vào/ra khỏi "Đã hủy" / "Đã hoàn hàng".
        $result = update_order_status($conn, $orderId, $newStatus);
        if ($result['ok']) {
            $flash = 'Đã cập nhật trạng thái đơn #' . $orderId . '.';
            log_admin_action($conn, (int)$me['id'], 'order.status', "#$orderId", "→ $newStatus");
        } else {
            $error = $result['message'];
        }
    }
}

$filterStatus = (string)($_GET['status'] ?? '');
$q = trim((string)($_GET['q'] ?? ''));
[$whereSql, $types, $params] = admin_orders_filter($statusList, $_GET);
$from = " FROM orders o JOIN users u ON o.user_id = u.id" . $whereSql;

$cnt = $conn->prepare("SELECT COUNT(*)" . $from);
if ($types !== '') $cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];

$perPage = 15;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare("SELECT o.*, u.username" . $from . " ORDER BY o.id DESC LIMIT ? OFFSET ?");
$stmt->bind_param($types . 'ii', ...array_merge($params, [$perPage, $pg['offset']]));
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Số đơn theo từng trạng thái cho các chip lọc
$counts = [];
foreach ($conn->query("SELECT status, COUNT(*) c FROM orders GROUP BY status") as $row) $counts[$row['status']] = (int)$row['c'];
$allCount = array_sum($counts);

$exportQs = http_build_query(array_filter(['status' => $filterStatus, 'q' => $q]));
$page_subtitle = $total . ' đơn' . (($filterStatus !== '' || $q !== '') ? ' phù hợp bộ lọc' : '');
$head_actions = '<a class="b b-ghost" href="export_orders.php' . ($exportQs ? '?' . htmlspecialchars($exportQs) : '') . '">Xuất CSV</a>';

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="chips">
  <a class="chip<?php echo $filterStatus === '' ? ' active' : ''; ?>" href="orders.php<?php echo $q !== '' ? '?q=' . urlencode($q) : ''; ?>">Tất cả<span class="n"><?php echo $allCount; ?></span></a>
  <?php foreach ($statusList as $s): if (empty($counts[$s])) continue; ?>
    <a class="chip<?php echo $filterStatus === $s ? ' active' : ''; ?>" href="orders.php?<?php echo htmlspecialchars(http_build_query(array_filter(['status' => $s, 'q' => $q]))); ?>"><?php echo htmlspecialchars($s); ?><span class="n"><?php echo $counts[$s]; ?></span></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <form method="get" class="filters">
    <?php if ($filterStatus !== ''): ?><input type="hidden" name="status" value="<?php echo htmlspecialchars($filterStatus); ?>"><?php endif; ?>
    <div class="grow"><label for="q">Tìm đơn hàng</label>
      <input type="search" id="q" name="q" placeholder="Mã đơn, tên khách, SĐT hoặc địa chỉ" value="<?php echo htmlspecialchars($q); ?>"></div>
    <div class="shrink"><button type="submit" class="b">Tìm</button>
      <?php if ($q !== ''): ?><a class="b b-ghost" href="orders.php<?php echo $filterStatus !== '' ? '?status=' . urlencode($filterStatus) : ''; ?>">Xoá tìm kiếm</a><?php endif; ?></div>
  </form>

  <div class="tbl-wrap"><table>
    <tr><th>Mã đơn</th><th>Khách hàng</th><th class="num">Tổng tiền</th><th>Giao đến</th><th>Trạng thái</th><th>Ngày tạo</th><th>Cập nhật</th></tr>
    <?php if (!$orders): ?><tr><td colspan="7" class="empty">Không có đơn hàng nào khớp.</td></tr><?php endif; ?>
    <?php foreach ($orders as $o): ?>
      <tr>
        <td><a href="order_view.php?id=<?php echo (int)$o['id']; ?>"><strong>#<?php echo (int)$o['id']; ?></strong></a></td>
        <td><?php echo htmlspecialchars($o['username']); ?></td>
        <td class="num"><?php echo vnd($o['total']); ?></td>
        <td class="muted"><?php echo htmlspecialchars($o['address'] ?? '—'); ?><br><?php echo htmlspecialchars($o['phone'] ?? ''); ?></td>
        <td><span class="tag <?php echo order_status_tone($o['status']); ?>"><?php echo htmlspecialchars($o['status']); ?></span></td>
        <td class="muted"><?php echo htmlspecialchars($o['created_at']); ?></td>
        <td>
          <form method="post" class="row-actions">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="order_id" value="<?php echo (int)$o['id']; ?>">
            <select name="status" style="width:auto;padding:5px 8px;" aria-label="Trạng thái đơn #<?php echo (int)$o['id']; ?>">
              <?php foreach ($statusList as $s): ?>
                <option value="<?php echo htmlspecialchars($s); ?>" <?php echo $o['status'] === $s ? 'selected' : ''; ?>><?php echo htmlspecialchars($s); ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="b b-ghost b-sm">Lưu</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php echo pagination_html($pg, ['status' => $filterStatus, 'q' => $q]); ?>
</div>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
