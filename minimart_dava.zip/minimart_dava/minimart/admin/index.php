<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';

// Admin và cộng tác viên đều vào được; nội dung bên dưới thay đổi theo quyền của từng người.
require_permission('dashboard.view');
$me = current_user();
$active_nav = 'index';
$page_title = 'Bảng điều khiển';
$page_subtitle = 'Xin chào ' . $me['username'] . ' — ' . role_label($me['role']);

$excluded = revenue_excluded_statuses();
$exPlaceholders = implode(',', array_fill(0, count($excluded), '?'));
$exTypes = str_repeat('s', count($excluded));
$low = low_stock_threshold();

function scalar(mysqli $conn, string $sql, string $types = '', array $params = []) {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_row();
    return $row[0] ?? 0;
}

// ----- Số liệu sản phẩm / đánh giá (ai cũng thấy) -----
$totalProducts = (int)scalar($conn, "SELECT COUNT(*) FROM products");
$outOfStock    = (int)scalar($conn, "SELECT COUNT(*) FROM products WHERE stock = 0");
$lowStock      = (int)scalar($conn, "SELECT COUNT(*) FROM products WHERE stock > 0 AND stock <= ?", 'i', [$low]);
$unanswered    = (int)scalar($conn,
    "SELECT COUNT(*) FROM reviews r WHERE NOT EXISTS (
        SELECT 1 FROM review_replies rr JOIN users u ON rr.user_id = u.id
        WHERE rr.review_id = r.id AND u.role IN ('admin','collaborator'))");
$totalReviews  = (int)scalar($conn, "SELECT COUNT(*) FROM reviews");

$lowList = $conn->prepare("SELECT id, name, stock FROM products WHERE stock <= ? ORDER BY stock ASC, id ASC LIMIT 6");
$lowList->bind_param('i', $low);
$lowList->execute();
$lowRows = $lowList->get_result()->fetch_all(MYSQLI_ASSOC);

$pendingReviews = $conn->query(
    "SELECT r.id, r.content, r.created_at, p.id AS pid, p.name AS pname, u.username
     FROM reviews r JOIN products p ON r.product_id = p.id JOIN users u ON r.user_id = u.id
     WHERE NOT EXISTS (SELECT 1 FROM review_replies rr JOIN users x ON rr.user_id = x.id
                       WHERE rr.review_id = r.id AND x.role IN ('admin','collaborator'))
     ORDER BY r.created_at DESC LIMIT 5"
)->fetch_all(MYSQLI_ASSOC);

// ----- Số liệu bán hàng / doanh thu / nhân sự (chỉ admin, tách riêng khỏi orders.manage
// để cộng tác viên có thể quản lý đơn hàng mà không thấy số liệu doanh thu nhạy cảm) -----
$isAdminView = has_permission('dashboard.revenue');
if ($isAdminView) {
    $revenueTotal = (float)scalar($conn, "SELECT COALESCE(SUM(total),0) FROM orders WHERE status NOT IN ($exPlaceholders)", $exTypes, $excluded);
    $revenueMonth = (float)scalar($conn, "SELECT COALESCE(SUM(total),0) FROM orders
        WHERE status NOT IN ($exPlaceholders) AND created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')", $exTypes, $excluded);
    $totalOrders  = (int)scalar($conn, "SELECT COUNT(*) FROM orders");
    $pendingOrders = (int)scalar($conn, "SELECT COUNT(*) FROM orders WHERE status IN ('Chờ xác nhận','Đang xử lý')");
    $returnRequests = (int)scalar($conn, "SELECT COUNT(*) FROM orders WHERE status = 'Yêu cầu hoàn hàng'");
    $totalCustomers = (int)scalar($conn, "SELECT COUNT(*) FROM users WHERE role = 'customer'");
    $newCustomers7 = (int)scalar($conn, "SELECT COUNT(*) FROM users WHERE role = 'customer' AND created_at >= CURDATE() - INTERVAL 6 DAY");
    $staffCount = (int)scalar($conn, "SELECT COUNT(*) FROM users WHERE role IN ('admin','collaborator')");

    // Doanh thu 7 ngày gần nhất (ngày không có đơn vẫn hiện cột 0)
    $stmt = $conn->prepare("SELECT DATE(created_at) d, COALESCE(SUM(total),0) s FROM orders
        WHERE status NOT IN ($exPlaceholders) AND created_at >= CURDATE() - INTERVAL 6 DAY GROUP BY DATE(created_at)");
    $stmt->bind_param($exTypes, ...$excluded);
    $stmt->execute();
    $byDay = [];
    foreach ($stmt->get_result() as $r) $byDay[$r['d']] = (float)$r['s'];
    $days = [];
    for ($i = 6; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i day"));
        $days[] = ['label' => date('d/m', strtotime($d)), 'value' => $byDay[$d] ?? 0.0];
    }
    $maxDay = max(1, max(array_column($days, 'value')));

    $stmt = $conn->prepare("SELECT p.id, p.name, SUM(oi.quantity) qty, SUM(oi.quantity * oi.price) revenue
        FROM order_items oi JOIN orders o ON oi.order_id = o.id JOIN products p ON oi.product_id = p.id
        WHERE o.status NOT IN ($exPlaceholders) GROUP BY p.id, p.name ORDER BY qty DESC, revenue DESC LIMIT 5");
    $stmt->bind_param($exTypes, ...$excluded);
    $stmt->execute();
    $topProducts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $recentOrders = $conn->query(
        "SELECT o.id, o.total, o.status, o.created_at, u.username FROM orders o JOIN users u ON o.user_id = u.id
         ORDER BY o.id DESC LIMIT 6"
    )->fetch_all(MYSQLI_ASSOC);
}

require __DIR__ . '/../includes/admin_header.php';
?>

<?php if ($isAdminView): ?>
  <div class="kpis">
    <div class="kpi t-teal">
      <div class="kpi-label">Doanh thu tháng này</div>
      <div class="kpi-value"><?php echo vnd($revenueMonth); ?></div>
      <div class="kpi-sub">Tổng cộng: <?php echo vnd($revenueTotal); ?> (không tính đơn huỷ/hoàn)</div>
    </div>
    <div class="kpi t-warn"><a href="orders.php?status=<?php echo urlencode('Chờ xác nhận'); ?>">
      <div class="kpi-label">Đơn chờ xử lý</div>
      <div class="kpi-value"><?php echo $pendingOrders; ?></div>
      <div class="kpi-sub">Trên tổng <?php echo $totalOrders; ?> đơn</div></a>
    </div>
    <div class="kpi <?php echo $returnRequests ? 't-bad' : ''; ?>"><a href="orders.php?status=<?php echo urlencode('Yêu cầu hoàn hàng'); ?>">
      <div class="kpi-label">Yêu cầu hoàn hàng</div>
      <div class="kpi-value"><?php echo $returnRequests; ?></div>
      <div class="kpi-sub"><?php echo $returnRequests ? 'Cần duyệt hoặc từ chối' : 'Không có yêu cầu nào'; ?></div></a>
    </div>
    <div class="kpi">
      <div class="kpi-label">Khách hàng</div>
      <div class="kpi-value"><?php echo $totalCustomers; ?></div>
      <div class="kpi-sub">+<?php echo $newCustomers7; ?> trong 7 ngày · <?php echo $staffCount; ?> nhân sự</div>
    </div>
  </div>
<?php endif; ?>

<div class="kpis">
  <div class="kpi"><a href="products.php">
    <div class="kpi-label">Sản phẩm đang bán</div>
    <div class="kpi-value"><?php echo $totalProducts; ?></div>
    <div class="kpi-sub">Quản lý trong mục Sản phẩm</div></a>
  </div>
  <div class="kpi <?php echo $lowStock ? 't-warn' : ''; ?>"><a href="products.php?stock=low">
    <div class="kpi-label">Sắp hết hàng (≤ <?php echo $low; ?>)</div>
    <div class="kpi-value"><?php echo $lowStock; ?></div>
    <div class="kpi-sub">Nên nhập thêm sớm</div></a>
  </div>
  <div class="kpi <?php echo $outOfStock ? 't-bad' : ''; ?>"><a href="products.php?stock=out">
    <div class="kpi-label">Hết hàng</div>
    <div class="kpi-value"><?php echo $outOfStock; ?></div>
    <div class="kpi-sub">Khách không đặt được</div></a>
  </div>
  <div class="kpi <?php echo $unanswered ? 't-warn' : 't-teal'; ?>"><a href="reviews.php?filter=pending">
    <div class="kpi-label">Đánh giá chưa trả lời</div>
    <div class="kpi-value"><?php echo $unanswered; ?></div>
    <div class="kpi-sub">Trên tổng <?php echo $totalReviews; ?> đánh giá</div></a>
  </div>
</div>

<?php if ($isAdminView): ?>
  <div class="adm-cols">
    <div class="card">
      <div class="card-head"><h3>Doanh thu 7 ngày gần nhất</h3><span class="hint" style="margin:0;">Tính theo ngày tạo đơn</span></div>
      <div class="bars" role="img" aria-label="Biểu đồ doanh thu 7 ngày gần nhất">
        <?php foreach ($days as $d):
            $h = $d['value'] > 0 ? max(4, (int)round($d['value'] / $maxDay * 120)) : 3; ?>
          <div class="bar">
            <span class="bar-val"><?php echo $d['value'] > 0 ? number_format($d['value'] / 1000, 0, ',', '.') . 'k' : ''; ?></span>
            <div class="bar-fill<?php echo $d['value'] > 0 ? '' : ' zero'; ?>" style="height:<?php echo $h; ?>px;"></div>
            <span class="bar-day"><?php echo htmlspecialchars($d['label']); ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card">
      <h3>Bán chạy nhất</h3>
      <?php if (!$topProducts): ?><p class="muted">Chưa có dữ liệu bán hàng.</p><?php else: ?>
        <ul class="mini-list">
          <?php foreach ($topProducts as $tp): ?>
            <li><span><?php echo htmlspecialchars($tp['name']); ?><div class="sub"><?php echo vnd($tp['revenue']); ?></div></span><strong><?php echo (int)$tp['qty']; ?> đã bán</strong></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
  <div style="height:20px;"></div>

  <div class="card">
    <div class="card-head"><h3>Đơn hàng mới nhất</h3><a class="b b-ghost b-sm" href="orders.php">Xem tất cả</a></div>
    <div class="tbl-wrap"><table>
      <tr><th>Mã đơn</th><th>Khách hàng</th><th class="num">Tổng tiền</th><th>Trạng thái</th><th>Ngày tạo</th></tr>
      <?php foreach ($recentOrders as $o): ?>
        <tr>
          <td><a href="order_view.php?id=<?php echo (int)$o['id']; ?>">#<?php echo (int)$o['id']; ?></a></td>
          <td><?php echo htmlspecialchars($o['username']); ?></td>
          <td class="num"><?php echo vnd($o['total']); ?></td>
          <td><span class="tag <?php echo order_status_tone($o['status']); ?>"><?php echo htmlspecialchars($o['status']); ?></span></td>
          <td class="muted"><?php echo htmlspecialchars($o['created_at']); ?></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
<?php endif; ?>

<div class="adm-cols adm-cols-even">
  <div class="card">
    <div class="card-head"><h3>Cần bổ sung hàng</h3><a class="b b-ghost b-sm" href="products.php?stock=low">Xem</a></div>
    <?php if (!$lowRows): ?><p class="muted">Tất cả sản phẩm đều còn đủ hàng.</p><?php else: ?>
      <ul class="mini-list">
        <?php foreach ($lowRows as $p): ?>
          <li>
            <a href="products.php?edit=<?php echo (int)$p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?></a>
            <span class="tag <?php echo (int)$p['stock'] === 0 ? 'bad' : 'warn'; ?>"><?php echo (int)$p['stock'] === 0 ? 'Hết hàng' : 'Còn ' . (int)$p['stock']; ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>Đánh giá đang chờ trả lời</h3><a class="b b-ghost b-sm" href="reviews.php?filter=pending">Xem</a></div>
    <?php if (!$pendingReviews): ?><p class="muted">Bạn đã trả lời hết đánh giá.</p><?php else: ?>
      <ul class="mini-list">
        <?php foreach ($pendingReviews as $r): ?>
          <li>
            <span>
              <?php echo htmlspecialchars(mb_strimwidth($r['content'], 0, 70, '…')); ?>
              <div class="sub"><?php echo htmlspecialchars($r['username']); ?> · <?php echo htmlspecialchars($r['pname']); ?></div>
            </span>
            <a href="reviews.php?filter=pending#review-<?php echo (int)$r['id']; ?>">Trả lời</a>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</div>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
