<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

// Chỉ admin: duyệt/từ chối yêu cầu rút hoa hồng và chỉnh tỷ lệ hoa hồng của từng cộng tác viên.
require_permission('payouts.manage');
admin_require_csrf();
$me = current_user();
$active_nav = 'payouts';
$page_title = 'Hoa hồng cộng tác viên';
$page_subtitle = 'Duyệt yêu cầu rút tiền, theo dõi số dư và chỉnh tỷ lệ hoa hồng.';
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'approve' || $action === 'reject') {
        $id = (int)($_POST['id'] ?? 0);
        $note = trim((string)($_POST['note'] ?? ''));
        $newStatus = $action === 'approve' ? 'Đã chi' : 'Từ chối';
        if ($action === 'reject' && $note === '') {
            $error = 'Vui lòng nhập lý do khi từ chối yêu cầu.';
        } else {
            $note = mb_substr($note, 0, 255);
            // WHERE status = 'Chờ duyệt' chống xử lý hai lần cùng một yêu cầu.
            $stmt = $conn->prepare("UPDATE ctv_payouts SET status = ?, admin_note = ?, processed_by = ?, processed_at = NOW()
                                    WHERE id = ? AND status = 'Chờ duyệt'");
            $adminId = (int)$me['id'];
            $stmt->bind_param('ssii', $newStatus, $note, $adminId, $id);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $flash = $action === 'approve' ? "Đã đánh dấu yêu cầu #$id là ĐÃ CHI." : "Đã từ chối yêu cầu #$id.";
                log_admin_action($conn, $adminId, $action === 'approve' ? 'payout.approve' : 'payout.reject', "#$id", $note);
            } else {
                $error = 'Yêu cầu này không còn ở trạng thái chờ duyệt.';
            }
        }
    } elseif ($action === 'set_rate') {
        $id = (int)($_POST['id'] ?? 0);
        $rate = $_POST['rate'] ?? '';
        if (!is_numeric($rate) || (float)$rate < 0 || (float)$rate > 50) {
            $error = 'Tỷ lệ hoa hồng phải nằm trong khoảng 0–50%.';
        } else {
            $rate = round((float)$rate, 1);
            // Chỉ đổi cho tài khoản cộng tác viên; các đơn đã đặt giữ nguyên tỷ lệ đã chốt.
            $stmt = $conn->prepare("UPDATE users SET commission_rate = ? WHERE id = ? AND role = 'collaborator'");
            $stmt->bind_param('di', $rate, $id);
            $stmt->execute();
            $flash = 'Đã cập nhật tỷ lệ hoa hồng (áp dụng cho đơn đặt từ bây giờ).';
            log_admin_action($conn, (int)$me['id'], 'ctv.rate', "user #$id", $rate . '%');
        }
    }
}

$statusFilter = (string)($_GET['status'] ?? 'Chờ duyệt');
$validStatus = ['Chờ duyệt', 'Đã chi', 'Từ chối'];
if ($statusFilter !== 'all' && !in_array($statusFilter, $validStatus, true)) $statusFilter = 'Chờ duyệt';

$counts = [];
foreach ($conn->query("SELECT status, COUNT(*) c FROM ctv_payouts GROUP BY status") as $r) $counts[$r['status']] = (int)$r['c'];

$sql = "SELECT p.*, u.username FROM ctv_payouts p JOIN users u ON u.id = p.user_id";
if ($statusFilter !== 'all') {
    $stmt = $conn->prepare($sql . " WHERE p.status = ? ORDER BY p.id DESC LIMIT 100");
    $stmt->bind_param('s', $statusFilter);
} else {
    $stmt = $conn->prepare($sql . " ORDER BY p.id DESC LIMIT 100");
}
$stmt->execute();
$payouts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$ctvs = $conn->query("SELECT id, username, ref_code, commission_rate, is_locked FROM users WHERE role = 'collaborator' ORDER BY username")->fetch_all(MYSQLI_ASSOC);
foreach ($ctvs as &$c) { $c['bal'] = ctv_balance($conn, (int)$c['id']); }
unset($c);

require __DIR__ . '/../includes/admin_header.php';
admin_flash($flash, $error);
?>
<div class="chips">
  <a class="chip<?php echo $statusFilter === 'Chờ duyệt' ? ' active' : ''; ?>" href="payouts.php">Chờ duyệt<span class="n"><?php echo $counts['Chờ duyệt'] ?? 0; ?></span></a>
  <a class="chip<?php echo $statusFilter === 'Đã chi' ? ' active' : ''; ?>" href="?status=<?php echo urlencode('Đã chi'); ?>">Đã chi<span class="n"><?php echo $counts['Đã chi'] ?? 0; ?></span></a>
  <a class="chip<?php echo $statusFilter === 'Từ chối' ? ' active' : ''; ?>" href="?status=<?php echo urlencode('Từ chối'); ?>">Từ chối<span class="n"><?php echo $counts['Từ chối'] ?? 0; ?></span></a>
  <a class="chip<?php echo $statusFilter === 'all' ? ' active' : ''; ?>" href="?status=all">Tất cả</a>
</div>

<div class="card">
  <div class="tbl-wrap"><table>
    <tr><th>Mã</th><th>Cộng tác viên</th><th class="num">Số tiền</th><th>Thông tin nhận tiền</th><th>Ngày gửi</th><th>Trạng thái</th><th></th></tr>
    <?php if (!$payouts): ?><tr><td colspan="7" class="empty">Không có yêu cầu nào ở nhóm này.</td></tr><?php endif; ?>
    <?php foreach ($payouts as $p): ?>
      <tr>
        <td>#<?php echo (int)$p['id']; ?></td>
        <td><strong><?php echo htmlspecialchars($p['username']); ?></strong></td>
        <td class="num"><strong><?php echo vnd($p['amount']); ?></strong></td>
        <td><?php echo htmlspecialchars($p['bank_info']); ?></td>
        <td class="muted"><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($p['created_at']))); ?></td>
        <td><span class="tag <?php echo ctv_payout_tone($p['status']); ?>"><?php echo htmlspecialchars($p['status']); ?></span>
          <?php if (!empty($p['admin_note'])): ?><div class="muted"><?php echo htmlspecialchars($p['admin_note']); ?></div><?php endif; ?></td>
        <td>
          <?php if ($p['status'] === 'Chờ duyệt'): ?>
            <div class="row-actions">
              <form method="post" onsubmit="return confirm('Xác nhận đã chuyển <?php echo htmlspecialchars(vnd($p['amount']), ENT_QUOTES); ?> cho <?php echo htmlspecialchars($p['username'], ENT_QUOTES); ?>?');">
                <?php echo csrf_field(); ?><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <button type="submit" class="b b-sm">Đã chi</button>
              </form>
              <form method="post" class="row-actions">
                <?php echo csrf_field(); ?><input type="hidden" name="action" value="reject"><input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <input type="text" name="note" placeholder="Lý do từ chối" maxlength="255" style="width:150px;padding:5px 8px;" required>
                <button type="submit" class="b b-danger b-sm">Từ chối</button>
              </form>
            </div>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>

<div class="card">
  <div class="card-head"><h3>Cộng tác viên</h3><span class="hint" style="margin:0;">Đổi tỷ lệ chỉ áp dụng cho đơn đặt sau đó</span></div>
  <div class="tbl-wrap"><table>
    <tr><th>Tài khoản</th><th>Mã giới thiệu</th><th class="num">Đã ghi nhận</th><th class="num">Chờ đối soát</th><th class="num">Đã chi</th><th class="num">Có thể rút</th><th>Hoa hồng (%)</th></tr>
    <?php if (!$ctvs): ?><tr><td colspan="7" class="empty">Chưa có cộng tác viên nào. Nâng quyền người dùng ở mục Người dùng.</td></tr><?php endif; ?>
    <?php foreach ($ctvs as $c): ?>
      <tr>
        <td><strong><?php echo htmlspecialchars($c['username']); ?></strong> <?php echo $c['is_locked'] ? '<span class="tag bad">Đã khoá</span>' : ''; ?></td>
        <td class="muted"><?php echo htmlspecialchars($c['ref_code'] ?? '— (tạo khi vào cổng lần đầu)'); ?></td>
        <td class="num"><?php echo vnd($c['bal']['earned']); ?></td>
        <td class="num"><?php echo vnd($c['bal']['pending']); ?></td>
        <td class="num"><?php echo vnd($c['bal']['paid']); ?></td>
        <td class="num"><strong><?php echo vnd($c['bal']['available']); ?></strong></td>
        <td>
          <form method="post" class="row-actions">
            <?php echo csrf_field(); ?><input type="hidden" name="action" value="set_rate"><input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
            <input type="number" name="rate" min="0" max="50" step="0.5" value="<?php echo htmlspecialchars((string)(float)$c['commission_rate']); ?>" style="width:80px;padding:5px 8px;" aria-label="Tỷ lệ hoa hồng của <?php echo htmlspecialchars($c['username']); ?>">
            <button type="submit" class="b b-ghost b-sm">Lưu</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
