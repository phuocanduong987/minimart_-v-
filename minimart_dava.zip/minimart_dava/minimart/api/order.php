<?php
/**
 * GET /api/order.php?id=<order_id>
 * Header:  Authorization: Bearer <token>      (token lấy ở trang Hồ sơ)
 *
 * [ĐÃ VÁ - API2:2023 Broken Authentication]
 *   Bắt buộc có token, token phải tồn tại trong api_tokens và thuộc tài khoản chưa bị khoá.
 *   Thiếu / sai token -> 401. Token được nhận qua header Authorization, KHÔNG qua URL
 *   (URL bị lưu trong log máy chủ, lịch sử trình duyệt, header Referer).
 *
 * [ĐÃ VÁ - API1:2023 Broken Object Level Authorization (BOLA)]
 *   Token hợp lệ chỉ chứng minh "bạn là ai", không cho phép đọc mọi đơn hàng. Đơn hàng chỉ
 *   trả về cho CHỦ ĐƠN, hoặc nhân sự (admin / cộng tác viên - cùng quy tắc với orders.php).
 *   Đơn của người khác trả 404 giống hệt đơn không tồn tại, để không lộ id nào có thật.
 */
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

/** Trả lỗi JSON và dừng. */
function api_fail(int $status, string $message, array $headers = []): void {
    http_response_code($status);
    foreach ($headers as $h) {
        header($h);
    }
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Lấy chuỗi token từ header "Authorization: Bearer ...". Trả '' nếu không có / sai dạng. */
function api_bearer_token(): string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($h === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'Authorization') === 0) {
                $h = $value;
                break;
            }
        }
    }
    if (preg_match('/^Bearer\s+(\S+)$/i', trim((string)$h), $m)) {
        return $m[1];
    }
    return '';
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    api_fail(405, 'Phương thức không được hỗ trợ.', ['Allow: GET']);
}

/* ---------- 1) Xác thực: token có không, token có hợp lệ không ---------- */
$token = api_bearer_token();
$challenge = ['WWW-Authenticate: Bearer realm="minimart-api"'];

// Token do hệ thống sinh ra chỉ gồm chữ, số, '_' và '-' (tối đa 64 ký tự) -> loại ngay chuỗi lạ.
if ($token === '' || !preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $token)) {
    api_fail(401, 'Thiếu hoặc sai định dạng token. Gửi header "Authorization: Bearer <token>".', $challenge);
}

$auth = $conn->prepare(
    "SELECT u.id, u.role, u.is_locked
     FROM api_tokens t JOIN users u ON u.id = t.user_id
     WHERE t.token = ? LIMIT 1"
);
$auth->bind_param('s', $token);
$auth->execute();
$caller = $auth->get_result()->fetch_assoc();
$auth->close();

if (!$caller) {
    api_fail(401, 'Token không hợp lệ.', $challenge);
}
if ((int)$caller['is_locked'] === 1) {
    api_fail(403, 'Tài khoản đã bị khoá.');
}

/* ---------- 2) Dữ liệu đầu vào ---------- */
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    api_fail(400, 'Thiếu hoặc sai tham số id.');
}

/* ---------- 3) Lấy đơn + kiểm tra quyền trên CHÍNH đơn đó (chống BOLA) ---------- */
$stmt = $conn->prepare(
    "SELECT o.id, o.user_id, o.total, o.status, o.created_at, u.username
     FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?"
);
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

$isOwner = $order && (int)$order['user_id'] === (int)$caller['id'];
$isStaff = in_array($caller['role'], ['admin', 'collaborator'], true);

if (!$order || (!$isOwner && !$isStaff)) {
    api_fail(404, 'Không tìm thấy đơn hàng');
}

$items = $conn->prepare(
    "SELECT p.name, oi.quantity, oi.price FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?"
);
$items->bind_param('i', $id);
$items->execute();
$order['items'] = $items->get_result()->fetch_all(MYSQLI_ASSOC);
$items->close();

echo json_encode($order, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
