<?php
/**
 * Xử lý "Mua tất cả" từ giỏ hàng (giỏ hàng lưu ở localStorage phía trình duyệt,
 * xem assets/cart.js). Nhận JSON qua POST, tự tính lại giá/ship/voucher ở server
 * (không tin số liệu do client gửi lên) rồi tạo 1 đơn hàng gồm nhiều sản phẩm.
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/ctv.php';

header('Content-Type: application/json; charset=utf-8');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Bạn cần đăng nhập trước khi thanh toán.']);
    exit;
}
$me = current_user();

// Admin / cộng tác viên không được đặt hàng (kiểm tra ở server, không chỉ ẩn nút ở giao diện).
if (!can_purchase()) {
    http_response_code(403);
    echo json_encode(['error' => purchase_block_message()]);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body) || empty($body['items']) || !is_array($body['items'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Giỏ hàng trống hoặc dữ liệu không hợp lệ.']);
    exit;
}

$zone = (string)($body['zone'] ?? '');
$address = trim((string)($body['address'] ?? ''));
$phone = trim((string)($body['phone'] ?? ''));
$voucherCode = trim((string)($body['voucher_code'] ?? ''));

if ($address === '' || $phone === '') {
    http_response_code(400);
    echo json_encode(['error' => 'Vui lòng nhập đầy đủ địa chỉ giao hàng và số điện thoại.']);
    exit;
}

if (!preg_match('/^[0-9+ ]{8,15}$/', $phone)) {
    http_response_code(400);
    echo json_encode(['error' => 'Số điện thoại không hợp lệ.']);
    exit;
}

$rateTable = shipping_rate_table();
if (!isset($rateTable[$zone])) {
    http_response_code(400);
    echo json_encode(['error' => 'Khu vực giao hàng không hợp lệ.']);
    exit;
}

/*
 * [ĐÃ VÁ - Trusting Client Input / Price Tampering]
 * Giá luôn lấy từ bảng products trong DB. Client chỉ được gửi id sản phẩm và số lượng;
 * trường "price" (nếu có) trong body JSON bị bỏ qua hoàn toàn.
 */
$subtotal = 0.0;
$lineItems = [];
$seenIds = [];
foreach ($body['items'] as $it) {
    if (!is_array($it)) {
        continue;
    }
    $pid = (int)($it['id'] ?? 0);
    $qty = (int)($it['qty'] ?? 1);
    if ($pid <= 0 || $qty < 1 || $qty > 99) {
        http_response_code(400);
        echo json_encode(['error' => 'Số lượng sản phẩm không hợp lệ (1–99).']);
        exit;
    }
    if (isset($seenIds[$pid])) { // cùng 1 sản phẩm lặp nhiều dòng -> từ chối, tránh lách kiểm tra tồn kho
        http_response_code(400);
        echo json_encode(['error' => 'Sản phẩm bị lặp trong giỏ hàng.']);
        exit;
    }
    $seenIds[$pid] = true;
    $stmt = $conn->prepare("SELECT id, name, price, stock FROM products WHERE id = ?");
    $stmt->bind_param('i', $pid);
    $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$prod) {
        continue;
    }
    if ($prod['stock'] < $qty) {
        http_response_code(409);
        echo json_encode(['error' => 'Sản phẩm "' . $prod['name'] . '" chỉ còn ' . $prod['stock'] . ' trong kho.']);
        exit;
    }
    $price = (float)$prod['price']; // giá thật trong DB
    $subtotal += $price * $qty;
    $lineItems[] = ['id' => $prod['id'], 'qty' => $qty, 'price' => $price];
}

if (empty($lineItems)) {
    http_response_code(400);
    echo json_encode(['error' => 'Không có sản phẩm hợp lệ trong giỏ hàng.']);
    exit;
}

$shippingFee = shipping_fee_for($zone, $subtotal);

$discount = 0.0;
$appliedVoucherCode = null;
$voucherRow = null;
if ($voucherCode !== '') {
    $v = validate_voucher($conn, $voucherCode, $subtotal);
    if (!$v['ok']) {
        http_response_code(400);
        echo json_encode(['error' => $v['message']]);
        exit;
    }
    $discount = $v['discount'];
    $appliedVoucherCode = $v['voucher']['code'];
    $voucherRow = $v['voucher'];
    // Voucher loại "amount" trên đơn hàng này áp dụng vào phí ship trước, phần dư trừ vào tổng tiền hàng.
    if ($v['voucher']['discount_type'] === 'amount') {
        $shipDiscount = min($discount, $shippingFee);
        $shippingFee -= $shipDiscount;
    }
}

$total = max(0, $subtotal + $shippingFee - $discount);

$conn->begin_transaction();
try {
    $ins = $conn->prepare(
        "INSERT INTO orders (user_id, total, status, address, phone, shipping_fee, voucher_code, discount_amount)
         VALUES (?, ?, 'Chờ xác nhận', ?, ?, ?, ?, ?)"
    );
    $ins->bind_param('idssdsd', $me['id'], $total, $address, $phone, $shippingFee, $appliedVoucherCode, $discount);
    $ins->execute();
    $orderId = $ins->insert_id;

    $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    $stockStmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
    // Khoá theo thứ tự id tăng dần và trừ kho TRƯỚC khi chèn order_items: tránh deadlock InnoDB
    // (chèn order_items giữ khoá đọc dòng products rồi UPDATE đòi nâng lên khoá ghi).
    usort($lineItems, function ($a, $b) { return (int)$a['id'] <=> (int)$b['id']; });
    foreach ($lineItems as $li) {
        $stockStmt->bind_param('iii', $li['qty'], $li['id'], $li['qty']);
        $stockStmt->execute();
        // Nếu có người khác vừa mua hết hàng giữa lúc kiểm tra và lúc trừ kho
        // (race condition), affected_rows sẽ là 0 -> huỷ toàn bộ đơn thay vì
        // tạo đơn với số lượng vượt quá tồn kho thực tế.
        if ($stockStmt->affected_rows < 1) {
            throw new RuntimeException('Sản phẩm "' . $li['id'] . '" vừa hết hàng trong lúc xử lý đơn.');
        }
        $itemStmt->bind_param('iiid', $orderId, $li['id'], $li['qty'], $li['price']);
        $itemStmt->execute();
    }

    if ($voucherRow) {
        // [ĐÃ VÁ - Race condition] Kiểm tra giới hạn và tăng bộ đếm trong CÙNG MỘT câu UPDATE (nguyên tử):
        // hai đơn đến cùng lúc không thể cùng lấy lượt cuối cùng. affected_rows = 0 -> huỷ cả đơn.
        $vu = $conn->prepare(
            "UPDATE vouchers SET used_count = used_count + 1
             WHERE id = ? AND active = 1 AND (max_uses IS NULL OR used_count < max_uses)"
        );
        $vu->bind_param('i', $voucherRow['id']);
        $vu->execute();
        if ($vu->affected_rows < 1) {
            throw new RuntimeException('voucher_exhausted');
        }
    }

    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    if ($e->getMessage() === 'voucher_exhausted') {
        http_response_code(400);
        echo json_encode(['error' => 'Mã voucher đã hết lượt sử dụng.']);
        exit;
    }
    if ($e instanceof RuntimeException && strpos($e->getMessage(), 'vừa hết hàng') !== false) {
        http_response_code(409); // cùng mã với nhánh kiểm tra tồn kho phía trên
        echo json_encode(['error' => 'Một sản phẩm vừa hết hàng trong lúc xử lý đơn. Vui lòng kiểm tra lại giỏ hàng.']);
        exit;
    }
    http_response_code(500);
    echo json_encode(['error' => 'Không thể tạo đơn hàng, vui lòng thử lại.']);
    exit;
}

ctv_attach_referral($conn, (int)$orderId, (int)$me['id']); // đơn đến từ link của cộng tác viên?

echo json_encode([
    'order_id' => $orderId,
    'subtotal' => $subtotal,
    'shipping_fee' => $shippingFee,
    'discount' => $discount,
    'total' => $total,
]);
