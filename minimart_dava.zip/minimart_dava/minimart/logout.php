<?php
require_once __DIR__ . '/includes/auth.php';

// Huỷ hẳn phiên phía server và xoá cookie phiên ở trình duyệt:
// cookie PHPSESSID cũ (nếu ai đó đã sao chép) từ đây không còn đăng nhập được nữa.
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
header('Location: login.php');
exit;
