<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/db.php';

require_login();
$me = current_user();
$page_title = 'Hồ sơ';
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout_all'])) {
    // Đăng xuất mọi thiết bị khác (giữ lại phiên hiện tại). Có kiểm tra CSRF.
    if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        die('Yêu cầu không hợp lệ. Hãy quay lại và tải lại trang.');
    }
    revoke_user_sessions($conn, (int)$me['id'], true);
    session_regenerate_id(true);
    $flash = 'Đã đăng xuất khỏi mọi thiết bị khác.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = (string)($_POST['current_password'] ?? '');
    $newPassword     = (string)($_POST['new_password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_new_password'] ?? '');

    $pstmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $pstmt->bind_param('i', $me['id']);
    $pstmt->execute();
    $row = $pstmt->get_result()->fetch_assoc();

    if (!$row || !verify_password($currentPassword, (string)$row['password'])) {
        $error = 'Mật khẩu hiện tại không đúng.';
    } elseif (mb_strlen($newPassword) < 8) {
        $error = 'Mật khẩu mới phải có ít nhất 8 ký tự.';
    } elseif (!preg_match('/[A-Za-z]/', $newPassword) || !preg_match('/[0-9]/', $newPassword)) {
        $error = 'Mật khẩu mới phải chứa cả chữ và số.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'Xác nhận mật khẩu mới không khớp.';
    } elseif ($newPassword === $currentPassword) {
        $error = 'Mật khẩu mới phải khác mật khẩu hiện tại.';
    } else {
        $newHash = hash_password($newPassword);
        $u = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $u->bind_param('si', $newHash, $me['id']);
        $u->execute();
        revoke_user_sessions($conn, (int)$me['id'], true); // đăng xuất MỌI thiết bị khác (kẻ đang giữ cookie cũ mất phiên)
        session_regenerate_id(true);
        $flash = 'Đã đổi mật khẩu thành công.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    // Chỉ nhận ảnh thật: kiểm tra dung lượng, kiểm tra loại file THẬT bằng nội dung (không tin tên file /
    // Content-Type do client gửi), tự đặt tên và phần mở rộng, không dùng tên gốc.
    $maxSize = 2 * 1024 * 1024; // 2 MB
    $allowedTypes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
    ];
    $tmpPath = $_FILES['avatar']['tmp_name'];
    $realMime = (new finfo(FILEINFO_MIME_TYPE))->file($tmpPath);

    if (!is_uploaded_file($tmpPath)) {
        $error = 'Tải lên thất bại.';
    } elseif ($_FILES['avatar']['size'] > $maxSize) {
        $error = 'Ảnh quá lớn (tối đa 2 MB).';
    } elseif (!isset($allowedTypes[$realMime]) || @getimagesize($tmpPath) === false) {
        $error = 'Chỉ chấp nhận ảnh JPG, PNG, GIF hoặc WEBP.';
    } else {
        $filename = (int)$me['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $allowedTypes[$realMime];
        $target = __DIR__ . '/uploads/avatars/' . $filename;

        if (move_uploaded_file($tmpPath, $target)) {
            $relPath = 'uploads/avatars/' . $filename;
            $u = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
            $u->bind_param('si', $relPath, $me['id']);
            $u->execute();
            $me['avatar'] = $relPath;
            $flash = 'Đã cập nhật ảnh đại diện.';
        } else {
            $error = 'Tải lên thất bại.';
        }
    }
}

$tok = $conn->prepare("SELECT token FROM api_tokens WHERE user_id = ? LIMIT 1");
$tok->bind_param('i', $me['id']);
$tok->execute();
$tokenRow = $tok->get_result()->fetch_assoc();

require __DIR__ . '/includes/header.php';
?>

<div class="panel" style="max-width:520px;">
  <h2>Hồ sơ của tôi</h2>
  <?php if ($flash): ?><div class="flash ok"><?php echo htmlspecialchars($flash); ?></div><?php endif; ?>
  <?php if ($error): ?><div class="flash error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

  <p>
    <span class="avatar-sm">
      <?php if (!empty($me['avatar'])): ?>
        <img src="<?php echo htmlspecialchars($me['avatar']); ?>" alt="avatar">
      <?php endif; ?>
    </span>
    <strong><?php echo htmlspecialchars($me['username']); ?></strong>
  </p>
  <p class="muted">Email: <?php echo htmlspecialchars($me['email']); ?></p>
  <p class="muted">Vai trò: <span class="badge"><?php echo htmlspecialchars(role_label($me['role'])); ?></span></p>

  <form method="post" enctype="multipart/form-data" id="avatar-upload">
    <label for="avatar">Cập nhật ảnh đại diện</label>
    <input type="file" id="avatar" name="avatar" required>
    <button type="submit">Tải lên</button>
  </form>

  <hr style="margin:20px 0;border-color:var(--line);">
  <h3>Đổi mật khẩu</h3>
  <form method="post" onsubmit="return confirm('Đăng xuất khỏi mọi thiết bị khác?');" style="margin-bottom:18px;">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="logout_all" value="1">
    <button type="submit" class="btn btn-ghost">Đăng xuất mọi thiết bị khác</button>
    <div class="muted" style="margin-top:6px;">Dùng khi nghi ngờ tài khoản bị lộ phiên (ví dụ đăng nhập trên máy lạ).</div>
  </form>

  <form method="post">
    <input type="hidden" name="change_password" value="1">

    <label for="current_password">Mật khẩu hiện tại</label>
    <input type="password" id="current_password" name="current_password" required>

    <label for="new_password">Mật khẩu mới</label>
    <input type="password" id="new_password" name="new_password" required minlength="8"
           pattern="(?=.*[A-Za-z])(?=.*\d).{8,}"
           title="Ít nhất 8 ký tự, gồm cả chữ và số">
    <small class="muted">Ít nhất 8 ký tự, gồm cả chữ và số.</small>

    <label for="confirm_new_password">Nhập lại mật khẩu mới</label>
    <input type="password" id="confirm_new_password" name="confirm_new_password" required minlength="8">

    <button type="submit" class="btn" style="margin-top:16px;">Đổi mật khẩu</button>
  </form>

  <hr style="margin:20px 0;border-color:var(--line);">
  <p class="muted">Token API của bạn (dùng để test qua Postman/Burp):</p>
  <p><code><?php echo htmlspecialchars($tokenRow['token'] ?? ''); ?></code></p>
  <p class="muted">Ví dụ gọi API: <code>curl -H "Authorization: Bearer &lt;token&gt;" "http://localhost/minimart/api/order.php?id=1"</code></p>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
