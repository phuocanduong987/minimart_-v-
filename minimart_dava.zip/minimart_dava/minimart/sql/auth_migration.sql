USE minimart;

-- Lịch sử đăng nhập sai, dùng để giới hạn số lần thử (login.php) và hiển thị thời điểm mở khoá cho admin.
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_la_user (username, created_at),
    INDEX idx_la_ip (ip, created_at)
);

-- Hash md5 cũ trong bảng users KHÔNG cần đổi tay: login.php tự nâng cấp lên bcrypt khi người dùng đăng nhập đúng.
