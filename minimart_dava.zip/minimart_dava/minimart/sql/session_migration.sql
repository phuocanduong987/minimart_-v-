USE minimart;

-- Thu hồi phiên: tăng số này (đổi mật khẩu, 'đăng xuất mọi thiết bị') thì mọi phiên cũ mất hiệu lực.
ALTER TABLE users ADD COLUMN session_version INT NOT NULL DEFAULT 0 AFTER commission_rate;
