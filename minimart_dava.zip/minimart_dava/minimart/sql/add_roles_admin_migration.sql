-- Migration: phân quyền admin / cộng tác viên / khách + nhật ký thao tác.
-- Dùng file này NẾU bạn đã có DB từ trước và không muốn reset.
-- Nếu import lại reset_database.sql hoặc schema.sql mới thì KHÔNG cần chạy file này.

USE minimart;

-- 1) Thêm vai trò 'collaborator' (cộng tác viên).
ALTER TABLE users
    MODIFY COLUMN role ENUM('admin','collaborator','customer') NOT NULL DEFAULT 'customer';

-- 2) Nhật ký thao tác trong khu vực quản trị.
CREATE TABLE IF NOT EXISTS admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    target VARCHAR(100) DEFAULT NULL,
    detail VARCHAR(255) DEFAULT NULL,
    ip VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 3) (Tuỳ chọn) tài khoản cộng tác viên mẫu: ctv / ctv12345
INSERT IGNORE INTO users (username, email, password, role)
VALUES ('ctv', 'ctv@minimart.local', MD5('ctv12345'), 'collaborator');
