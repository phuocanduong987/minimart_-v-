-- Migration: Cổng cộng tác viên (/ctv) — sản phẩm của tôi, link giới thiệu, hoa hồng, rút tiền.
-- Chạy file này NẾU bạn đã có DB từ trước và không muốn reset.
-- Nếu import lại schema.sql / reset_database.sql mới thì KHÔNG cần chạy file này.
-- (Chạy một lần. Nếu báo "Duplicate column name" nghĩa là cột đã có sẵn.)

USE minimart;

-- 1) Mã giới thiệu + tỷ lệ hoa hồng của từng cộng tác viên.
ALTER TABLE users
    ADD COLUMN ref_code VARCHAR(20) NULL UNIQUE AFTER avatar,
    ADD COLUMN commission_rate DECIMAL(4,1) NOT NULL DEFAULT 5.0 AFTER ref_code;

-- 2) Sản phẩm do ai tạo (NULL = của cửa hàng/admin). Cộng tác viên chỉ sửa được sản phẩm của mình.
ALTER TABLE products
    ADD COLUMN created_by INT NULL AFTER subcategory,
    ADD CONSTRAINT fk_products_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;

-- 3) Đơn hàng đến từ link giới thiệu của cộng tác viên nào, tỷ lệ hoa hồng chốt tại thời điểm đặt.
ALTER TABLE orders
    ADD COLUMN ref_ctv_id INT NULL AFTER discount_amount,
    ADD COLUMN ctv_rate DECIMAL(4,1) NULL AFTER ref_ctv_id,
    ADD CONSTRAINT fk_orders_ref_ctv FOREIGN KEY (ref_ctv_id) REFERENCES users(id) ON DELETE SET NULL,
    ADD INDEX idx_orders_ref_ctv (ref_ctv_id);

-- 4) Yêu cầu rút hoa hồng.
CREATE TABLE IF NOT EXISTS ctv_payouts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    bank_info VARCHAR(255) NOT NULL,
    status ENUM('Chờ duyệt','Đã chi','Từ chối') NOT NULL DEFAULT 'Chờ duyệt',
    admin_note VARCHAR(255) DEFAULT NULL,
    processed_by INT NULL,
    processed_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payout_user (user_id, status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- 5) Dữ liệu mẫu: cấp mã giới thiệu cho tài khoản ctv, gán vài sản phẩm cho ctv,
--    và coi đơn #1 (đã giao) là đơn đến từ link của ctv để bảng hoa hồng có số liệu.
UPDATE users SET ref_code = 'CTV0003' WHERE username = 'ctv' AND ref_code IS NULL;
UPDATE products SET created_by = (SELECT id FROM (SELECT id FROM users WHERE username = 'ctv') x)
 WHERE id IN (1, 3, 6) AND created_by IS NULL;
UPDATE orders SET ref_ctv_id = (SELECT id FROM (SELECT id FROM users WHERE username = 'ctv') x), ctv_rate = 5.0
 WHERE id = 1 AND ref_ctv_id IS NULL;
