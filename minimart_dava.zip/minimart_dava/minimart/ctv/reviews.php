<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

require_collaborator();
admin_require_csrf();
$me = current_user();
$uid = (int)$me['id'];
$active_nav = 'reviews';
$page_title = 'Đánh giá của khách';
$page_subtitle = 'Chỉ gồm đánh giá của các sản phẩm bạn phụ trách. Phản hồi hiện công khai ở trang sản phẩm.';
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reply') {
    $reviewId = (int)($_POST['review_id'] ?? 0);
    $content = trim((string)($_POST['content'] ?? ''));

    // Chỉ được trả lời đánh giá thuộc sản phẩm do mình tạo.
    $chk = $conn->prepare("SELECT r.id FROM reviews r JOIN products p ON p.id = r.product_id WHERE r.id = ? AND p.created_by = ?");
    $chk->bind_param('ii', $reviewId, $uid);
    $chk->execute();
    if (!$chk->get_result()->fetch_assoc()) {
        http_response_code(403);
        $error = 'Bạn chỉ được trả lời đánh giá của sản phẩm do chính mình phụ trách.';
    } elseif ($content === '') {
        $error = 'Nội dung trả lời không được để trống.';
    } elseif (mb_strlen($content) > 1000) {
        $error = 'Nội dung trả lời tối đa 1000 ký tự.';
    } else {
        add_review_reply($conn, $reviewId, $uid, $content);
        $flash = 'Đã gửi trả lời.';
        log_admin_action($conn, $uid, 'review.reply', "review #$reviewId", mb_strimwidth($content, 0, 120, '…'));
    }
}

$filter = ($_GET['filter'] ?? '') === 'pending' ? 'pending' : 'all';
$productId = (int)($_GET['product'] ?? 0);
$q = trim((string)($_GET['q'] ?? ''));

$pendingSql = "NOT EXISTS (SELECT 1 FROM review_replies rr JOIN users x ON rr.user_id = x.id
                           WHERE rr.review_id = r.id AND x.role IN ('admin','collaborator'))";
$where = ['p.created_by = ?'];
$types = 'i';
$params = [$uid];
if ($filter === 'pending') $where[] = $pendingSql;
if ($productId > 0) { $where[] = 'r.product_id = ?'; $types .= 'i'; $params[] = $productId; }
if ($q !== '') {
    $where[] = '(r.content LIKE ? OR u.username LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss'; array_push($params, $like, $like);
}
$from = " FROM reviews r JOIN products p ON r.product_id = p.id JOIN users u ON r.user_id = u.id WHERE " . implode(' AND ', $where);

$cnt = $conn->prepare("SELECT COUNT(*)" . $from);
$cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];

$allCount = (int)$conn->query("SELECT COUNT(*) FROM reviews r JOIN products p ON p.id = r.product_id WHERE p.created_by = $uid")->fetch_row()[0];
$pendingCount = ctv_pending_reviews_count($conn, $uid);

$perPage = 10;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare(
    "SELECT r.id, r.content, r.created_at, p.id AS pid, p.name AS pname, u.username,
            (SELECT COUNT(*) FROM review_likes rl WHERE rl.review_id = r.id) AS likes"
    . $from . " ORDER BY r.created_at DESC, r.id DESC LIMIT ? OFFSET ?"
);
$stmt->bind_param($types . 'ii', ...array_merge($params, [$perPage, $pg['offset']]));
$stmt->execute();
$reviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$pl = $conn->prepare("SELECT id, name FROM products WHERE created_by = ? ORDER BY name");
$pl->bind_param('i', $uid);
$pl->execute();
$productList = $pl->get_result()->fetch_all(MYSQLI_ASSOC);

$keep = ['filter' => $filter === 'pending' ? 'pending' : '', 'product' => $productId ?: '', 'q' => $q];

require __DIR__ . '/../includes/ctv_header.php';
admin_flash($flash, $error);
?>
<div class="chips">
  <a class="chip<?php echo $filter === 'all' ? ' active' : ''; ?>" href="reviews.php">Tất cả<span class="n"><?php echo $allCount; ?></span></a>
  <a class="chip<?php echo $filter === 'pending' ? ' active' : ''; ?>" href="reviews.php?filter=pending">Chưa trả lời<span class="n"><?php echo $pendingCount; ?></span></a>
</div>

<div class="card">
  <form method="get" class="filters" style="margin-bottom:0;">
    <?php if ($filter === 'pending'): ?><input type="hidden" name="filter" value="pending"><?php endif; ?>
    <div class="grow"><label for="q">Tìm trong nội dung hoặc tên khách</label>
      <input type="search" id="q" name="q" value="<?php echo htmlspecialchars($q); ?>"></div>
    <div><label for="product">Sản phẩm</label>
      <select id="product" name="product">
        <option value="">Tất cả sản phẩm của tôi</option>
        <?php foreach ($productList as $pr): ?>
          <option value="<?php echo (int)$pr['id']; ?>" <?php echo $productId === (int)$pr['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($pr['name']); ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="shrink"><button type="submit" class="b">Lọc</button></div>
  </form>
</div>

<?php if (!$reviews): ?>
  <div class="card"><p class="empty" style="margin:0;">
    <?php echo !$productList ? 'Bạn chưa phụ trách sản phẩm nào nên chưa có đánh giá. Hãy thêm sản phẩm ở mục Sản phẩm.'
        : ($filter === 'pending' ? 'Không còn đánh giá nào chờ trả lời.' : 'Chưa có đánh giá nào khớp bộ lọc.'); ?></p></div>
<?php endif; ?>

<?php foreach ($reviews as $r):
    $rs = $conn->prepare("SELECT rr.id, rr.content, rr.created_at, u.username, u.role
                          FROM review_replies rr JOIN users u ON rr.user_id = u.id
                          WHERE rr.review_id = ? ORDER BY rr.created_at ASC, rr.id ASC");
    $rs->bind_param('i', $r['id']);
    $rs->execute();
    $replies = $rs->get_result()->fetch_all(MYSQLI_ASSOC);
    $hasStaffReply = false;
    foreach ($replies as $rep) { if (in_array($rep['role'], ['admin', 'collaborator'], true)) $hasStaffReply = true; }
?>
  <div class="rv<?php echo $hasStaffReply ? '' : ' pending'; ?>" id="review-<?php echo (int)$r['id']; ?>">
    <div class="rv-top">
      <span><strong style="color:var(--ink);"><?php echo htmlspecialchars($r['username']); ?></strong> về
        <a href="../product.php?id=<?php echo (int)$r['pid']; ?>#review-<?php echo (int)$r['id']; ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($r['pname']); ?></a></span>
      <span><?php echo (int)$r['likes']; ?> lượt thích · <?php echo htmlspecialchars($r['created_at']); ?>
        <?php if (!$hasStaffReply): ?> · <span class="tag warn">Chưa trả lời</span><?php endif; ?></span>
    </div>
    <?php /* Nội dung khách viết luôn được escape ở cổng cộng tác viên để mã độc (Stored XSS) không chạy được trên máy cộng tác viên. */ ?>
    <div class="rv-body"><?php echo htmlspecialchars($r['content']); ?></div>

    <?php foreach ($replies as $rep): ?>
      <div class="rv-reply">
        <div class="who"><?php echo htmlspecialchars($rep['username']); ?> <?php echo staff_badge_html($rep['role']); ?> · <?php echo htmlspecialchars($rep['created_at']); ?></div>
        <?php echo htmlspecialchars($rep['content']); ?>
      </div>
    <?php endforeach; ?>

    <details <?php echo $hasStaffReply ? '' : 'open'; ?>>
      <summary>Viết trả lời</summary>
      <form method="post" action="reviews.php?<?php echo htmlspecialchars(http_build_query(array_filter($keep) + ($pg['page'] > 1 ? ['page' => $pg['page']] : []))); ?>#review-<?php echo (int)$r['id']; ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="reply">
        <input type="hidden" name="review_id" value="<?php echo (int)$r['id']; ?>">
        <label for="reply-<?php echo (int)$r['id']; ?>">Trả lời với tên <?php echo htmlspecialchars($me['username']); ?> (<?php echo htmlspecialchars(role_label($me['role'])); ?>)</label>
        <textarea id="reply-<?php echo (int)$r['id']; ?>" name="content" maxlength="1000" required></textarea>
        <div class="form-actions"><button type="submit" class="b">Gửi trả lời</button></div>
      </form>
    </details>
  </div>
<?php endforeach; ?>

<?php echo pagination_html($pg, $keep); ?>
<?php require __DIR__ . '/../includes/ctv_footer.php'; ?>
