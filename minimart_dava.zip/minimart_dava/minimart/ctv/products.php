<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

require_collaborator();
admin_require_csrf();
$me = current_user();
$uid = (int)$me['id'];
$active_nav = 'products';
$flash = '';
$error = '';

$tree = category_tree();
$low = low_stock_threshold();
$code = ctv_ensure_ref_code($conn, $uid);

// Hai tab: "mine" = sản phẩm do mình tạo (sửa được); "catalog" = toàn bộ cửa hàng (chỉ xem + lấy link).
$view = (($_GET['view'] ?? '') === 'catalog') ? 'catalog' : 'mine';

function ctv_product_errors(string $name, $price, $stock): string {
    if ($name === '') return 'Vui lòng nhập tên sản phẩm.';
    if (mb_strlen($name) > 150) return 'Tên sản phẩm tối đa 150 ký tự.';
    if (!is_numeric($price) || (float)$price < 0) return 'Giá sản phẩm không hợp lệ.';
    if (!ctype_digit((string)$stock)) return 'Tồn kho phải là số nguyên không âm.';
    return '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'quick_stock') {
        $id = (int)($_POST['id'] ?? 0);
        $stock = $_POST['stock'] ?? '';
        if (!ctype_digit((string)$stock)) {
            $error = 'Tồn kho phải là số nguyên không âm.';
        } else {
            $stock = (int)$stock;
            // Điều kiện created_by chặn sửa sản phẩm của người khác ngay ở tầng SQL.
            $stmt = $conn->prepare("UPDATE products SET stock = ? WHERE id = ? AND created_by = ?");
            $stmt->bind_param('iii', $stock, $id, $uid);
            $stmt->execute();
            if ($stmt->affected_rows > 0 || ctv_owns_product($conn, $uid, $id)) {
                $flash = 'Đã cập nhật tồn kho.';
                log_admin_action($conn, $uid, 'product.stock', "#$id", "Tồn kho = $stock");
            } else {
                http_response_code(403);
                $error = 'Bạn chỉ được cập nhật sản phẩm do chính mình tạo.';
            }
        }
    } elseif ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        $description = trim((string)($_POST['description'] ?? ''));
        $price = $_POST['price'] ?? '0';
        $stock = $_POST['stock'] ?? '0';
        $category = (string)($_POST['category'] ?? '');
        $subcategory = (string)($_POST['subcategory'] ?? '');

        $err = ctv_product_errors($name, $price, $stock);
        if (!isset($tree[$category])) { $category = null; $subcategory = null; }
        elseif (!isset($tree[$category]['subs'][$subcategory])) { $subcategory = null; }

        if ($err !== '') {
            $error = $err;
        } elseif ($id > 0) {
            if (!ctv_owns_product($conn, $uid, $id)) {
                http_response_code(403);
                $error = 'Bạn chỉ được sửa sản phẩm do chính mình tạo.';
            } else {
                $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, stock=?, category=?, subcategory=? WHERE id=? AND created_by=?");
                $stmt->bind_param('ssdissii', $name, $description, $price, $stock, $category, $subcategory, $id, $uid);
                $stmt->execute();
                $flash = 'Đã cập nhật sản phẩm.';
                log_admin_action($conn, $uid, 'product.update', "#$id", $name);
            }
        } else {
            $stmt = $conn->prepare("INSERT INTO products (name, description, price, stock, category, subcategory, created_by) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param('ssdissi', $name, $description, $price, $stock, $category, $subcategory, $uid);
            $stmt->execute();
            $flash = 'Đã thêm sản phẩm mới. Sản phẩm hiển thị ngay trên cửa hàng.';
            log_admin_action($conn, $uid, 'product.create', '#' . $stmt->insert_id, $name);
        }
    }
}

// ----- Sản phẩm đang sửa (chỉ của mình) -----
$editProduct = null;
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND created_by = ?");
    $stmt->bind_param('ii', $editId, $uid);
    $stmt->execute();
    $editProduct = $stmt->get_result()->fetch_assoc();
    if (!$editProduct) $error = $error ?: 'Không tìm thấy sản phẩm của bạn với mã này.';
}

// ----- Lọc / tìm -----
$q = trim((string)($_GET['q'] ?? ''));
$stockFilter = (string)($_GET['stock'] ?? '');
$where = [];
$types = '';
$params = [];
if ($view === 'mine') { $where[] = 'created_by = ?'; $types .= 'i'; $params[] = $uid; }
if ($q !== '') {
    $where[] = '(name LIKE ? OR description LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss'; array_push($params, $like, $like);
}
if ($stockFilter === 'out') { $where[] = 'stock = 0'; }
elseif ($stockFilter === 'low') { $where[] = 'stock <= ?'; $types .= 'i'; $params[] = $low; }
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$cnt = $conn->prepare("SELECT COUNT(*) FROM products" . $whereSql);
if ($types !== '') $cnt->bind_param($types, ...$params);
$cnt->execute();
$total = (int)$cnt->get_result()->fetch_row()[0];

$perPage = 10;
$pg = paginate($total, $perPage, (int)($_GET['page'] ?? 1));
$stmt = $conn->prepare("SELECT * FROM products" . $whereSql . " ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bind_param($types . 'ii', ...array_merge($params, [$perPage, $pg['offset']]));
$stmt->execute();
$products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$page_title = 'Sản phẩm';
$page_subtitle = $view === 'mine'
    ? 'Sản phẩm do bạn tạo và phụ trách — bạn sửa giá, mô tả, tồn kho và trả lời đánh giá của chúng.'
    : 'Toàn bộ sản phẩm của cửa hàng. Lấy link giới thiệu riêng cho từng sản phẩm để chia sẻ.';
require __DIR__ . '/../includes/ctv_header.php';
admin_flash($flash, $error);

$keep = array_filter(['view' => $view === 'catalog' ? 'catalog' : null, 'q' => $q, 'stock' => $stockFilter]);
?>
<div class="chips">
  <a class="chip <?php echo $view === 'mine' ? 'active' : ''; ?>" href="products.php">Sản phẩm của tôi</a>
  <a class="chip <?php echo $view === 'catalog' ? 'active' : ''; ?>" href="products.php?view=catalog">Toàn bộ cửa hàng</a>
</div>

<div class="<?php echo $view === 'mine' ? 'adm-cols' : ''; ?>">
  <div class="card">
    <form method="get" class="filters">
      <?php if ($view === 'catalog'): ?><input type="hidden" name="view" value="catalog"><?php endif; ?>
      <div class="grow"><label for="q">Tìm sản phẩm</label>
        <input type="search" id="q" name="q" placeholder="Tên hoặc mô tả" value="<?php echo htmlspecialchars($q); ?>"></div>
      <div><label for="stock">Tồn kho</label>
        <select id="stock" name="stock">
          <option value="">Tất cả</option>
          <option value="low" <?php echo $stockFilter === 'low' ? 'selected' : ''; ?>>Sắp hết (≤ <?php echo $low; ?>)</option>
          <option value="out" <?php echo $stockFilter === 'out' ? 'selected' : ''; ?>>Hết hàng</option>
        </select></div>
      <div class="shrink"><button type="submit" class="b">Lọc</button>
        <?php if ($q !== '' || $stockFilter !== ''): ?><a class="b b-ghost" href="products.php<?php echo $view === 'catalog' ? '?view=catalog' : ''; ?>">Xoá lọc</a><?php endif; ?></div>
    </form>

    <div class="tbl-wrap"><table>
      <tr><th>Sản phẩm</th><th class="num">Giá</th><th>Tồn kho</th><th></th></tr>
      <?php if (!$products): ?>
        <tr><td colspan="4" class="empty"><?php echo $view === 'mine' ? 'Bạn chưa có sản phẩm nào. Thêm sản phẩm đầu tiên ở khung bên phải.' : 'Không có sản phẩm phù hợp.'; ?></td></tr>
      <?php endif; ?>
      <?php foreach ($products as $p): $mine = ((int)($p['created_by'] ?? 0) === $uid); ?>
        <tr>
          <td><strong><?php echo htmlspecialchars($p['name']); ?></strong>
            <div class="muted">#<?php echo (int)$p['id']; ?> · <?php echo htmlspecialchars(($tree[$p['category']]['label'] ?? $p['category']) ?: '—'); ?>
              <?php if ($view === 'catalog' && $mine): ?> · <span class="tag role-collaborator">Của tôi</span><?php endif; ?></div></td>
          <td class="num"><?php echo vnd($p['price']); ?></td>
          <td>
            <?php if ($mine): ?>
              <form method="post" class="row-actions">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="quick_stock">
                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <input type="number" name="stock" min="0" value="<?php echo (int)$p['stock']; ?>" style="width:72px;padding:5px 8px;" aria-label="Tồn kho sản phẩm #<?php echo (int)$p['id']; ?>">
                <button type="submit" class="b b-ghost b-sm">Lưu</button>
              </form>
            <?php else: ?>
              <?php echo (int)$p['stock']; ?>
            <?php endif; ?>
            <?php if ((int)$p['stock'] === 0): ?><span class="tag bad">Hết</span>
            <?php elseif ((int)$p['stock'] <= $low): ?><span class="tag warn">Sắp hết</span><?php endif; ?>
          </td>
          <td>
            <div class="row-actions">
              <?php if ($mine): ?>
                <a class="b b-ghost b-sm" href="?<?php echo htmlspecialchars(http_build_query($keep + ['edit' => $p['id']])); ?>#product-form">Sửa</a>
              <?php endif; ?>
              <input type="text" id="pl-<?php echo (int)$p['id']; ?>" value="<?php echo htmlspecialchars(ctv_referral_link($code, (int)$p['id'])); ?>" readonly style="position:absolute;left:-9999px;width:1px;" aria-hidden="true" tabindex="-1">
              <button type="button" class="b b-ghost b-sm" data-copy="pl-<?php echo (int)$p['id']; ?>" title="Sao chép link giới thiệu sản phẩm này">Lấy link</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
    <?php echo pagination_html($pg, $keep); ?>
    <p class="hint" style="margin-top:12px;">Bạn không xoá được sản phẩm. Muốn ngừng bán, hãy đặt tồn kho về 0.</p>
  </div>

  <?php if ($view === 'mine'): ?>
  <div class="card" id="product-form">
    <h3><?php echo $editProduct ? 'Sửa sản phẩm #' . (int)$editProduct['id'] : 'Thêm sản phẩm mới'; ?></h3>
    <form method="post" action="products.php<?php echo $editProduct ? '?edit=' . (int)$editProduct['id'] : ''; ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?php echo (int)($editProduct['id'] ?? 0); ?>">

      <label for="name">Tên sản phẩm</label>
      <input type="text" id="name" name="name" required maxlength="150" value="<?php echo htmlspecialchars($editProduct['name'] ?? ''); ?>">

      <label for="description">Mô tả</label>
      <textarea id="description" name="description"><?php echo htmlspecialchars($editProduct['description'] ?? ''); ?></textarea>

      <div class="form-grid">
        <div><label for="price">Giá (đ)</label>
          <input type="number" id="price" name="price" min="0" step="1000" required value="<?php echo htmlspecialchars((string)($editProduct['price'] ?? 0)); ?>"></div>
        <div><label for="pstock">Tồn kho</label>
          <input type="number" id="pstock" name="stock" min="0" required value="<?php echo htmlspecialchars((string)($editProduct['stock'] ?? 0)); ?>"></div>
      </div>

      <label for="category">Danh mục</label>
      <select id="category" name="category">
        <option value="">— Chọn danh mục —</option>
        <?php foreach ($tree as $catKey => $catInfo): ?>
          <option value="<?php echo htmlspecialchars($catKey); ?>" <?php echo (($editProduct['category'] ?? '') === $catKey) ? 'selected' : ''; ?>><?php echo htmlspecialchars($catInfo['label']); ?></option>
        <?php endforeach; ?>
      </select>

      <label for="subcategory">Danh mục con</label>
      <select id="subcategory" name="subcategory">
        <option value="">— Không có —</option>
        <?php foreach ($tree as $catKey => $catInfo): foreach ($catInfo['subs'] as $subKey => $subLabel): ?>
          <option value="<?php echo htmlspecialchars($subKey); ?>" data-parent="<?php echo htmlspecialchars($catKey); ?>"
            <?php echo (($editProduct['subcategory'] ?? '') === $subKey) ? 'selected' : ''; ?>><?php echo htmlspecialchars($subLabel); ?></option>
        <?php endforeach; endforeach; ?>
      </select>

      <div class="form-actions">
        <button type="submit" class="b"><?php echo $editProduct ? 'Lưu thay đổi' : 'Thêm sản phẩm'; ?></button>
        <?php if ($editProduct): ?><a class="b b-ghost" href="products.php">Huỷ sửa</a><?php endif; ?>
      </div>
    </form>
  </div>
  <script>
  (function () {
    var cat = document.getElementById('category'), sub = document.getElementById('subcategory');
    if (!cat || !sub) return;
    function sync() {
      Array.prototype.forEach.call(sub.options, function (o) {
        if (!o.dataset.parent) return;
        var show = o.dataset.parent === cat.value;
        o.hidden = !show; o.disabled = !show;
        if (!show && o.selected) sub.value = '';
      });
    }
    cat.addEventListener('change', function () { sub.value = ''; sync(); });
    sync();
  })();
  </script>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/ctv_footer.php'; ?>
