<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

require_collaborator();
$me = current_user();
$uid = (int)$me['id'];
$active_nav = 'referrals';
$page_title = 'Giới thiệu & đơn hàng';
$page_subtitle = 'Các đơn khách đặt qua link của bạn và hoa hồng tương ứng.';

$code = ctv_ensure_ref_code($conn, $uid);
$link = ctv_referral_link($code);
$rate = ctv_commission_rate($conn, $uid);
$bal = ctv_balance($conn, $uid);

$all = ctv_orders($conn, $uid);
$counts = ['earned' => 0, 'pending' => 0, 'void' => 0];
foreach ($all as $o) $counts[$o['state']]++;

$filter = (string)($_GET['state'] ?? '');
$rows = ($filter !== '' && isset($counts[$filter]))
    ? array_values(array_filter($all, fn($o) => $o['state'] === $filter))
    : $all;
if (!isset($counts[$filter])) $filter = '';

$perPage = 12;
$pg = paginate(count($rows), $perPage, (int)($_GET['page'] ?? 1));
$rows = array_slice($rows, $pg['offset'], $perPage);

require __DIR__ . '/../includes/ctv_header.php';
?>
<section class="ref-hero">
  <div>
    <h2>Link giới thiệu chung</h2>
    <p>Gửi link này cho bạn bè, đăng lên mạng xã hội hoặc nhóm bán hàng. Muốn giới thiệu một món cụ thể? Vào <a href="products.php?view=catalog" style="color:#fff;text-decoration:underline;">Sản phẩm → Toàn bộ cửa hàng</a> và bấm “Lấy link”.</p>
    <div class="ref-box">
      <input type="text" id="ref-link" value="<?php echo htmlspecialchars($link); ?>" readonly aria-label="Link giới thiệu">
      <button type="button" class="b" data-copy="ref-link">Sao chép link</button>
    </div>
  </div>
  <div class="ref-code"><span>Mã giới thiệu</span><strong><?php echo htmlspecialchars($code); ?></strong></div>
</section>

<div class="note">
  <strong>Cách tính hoa hồng:</strong> <?php echo ctv_pct($rate); ?>% × giá trị hàng hoá trong đơn (chưa gồm phí vận chuyển).
  Đơn <em>Đã giao</em> được ghi nhận và rút được; đơn đang xử lý ở trạng thái <em>Chờ đối soát</em>; đơn <em>Đã hủy / Đã hoàn hàng</em> không có hoa hồng.
  Link có hiệu lực 30 ngày kể từ lần khách bấm vào.
</div>

<div class="chips">
  <a class="chip<?php echo $filter === '' ? ' active' : ''; ?>" href="referrals.php">Tất cả<span class="n"><?php echo count($all); ?></span></a>
  <a class="chip<?php echo $filter === 'earned' ? ' active' : ''; ?>" href="?state=earned">Đã ghi nhận<span class="n"><?php echo $counts['earned']; ?></span></a>
  <a class="chip<?php echo $filter === 'pending' ? ' active' : ''; ?>" href="?state=pending">Chờ đối soát<span class="n"><?php echo $counts['pending']; ?></span></a>
  <a class="chip<?php echo $filter === 'void' ? ' active' : ''; ?>" href="?state=void">Không tính<span class="n"><?php echo $counts['void']; ?></span></a>
</div>

<div class="card">
  <div class="tbl-wrap"><table>
    <tr><th>Đơn</th><th>Ngày đặt</th><th>Khách</th><th class="num">Giá trị hàng</th><th class="num">Hoa hồng</th><th>Trạng thái</th></tr>
    <?php if (!$rows): ?>
      <tr><td colspan="6" class="empty"><?php echo $all ? 'Không có đơn nào ở nhóm này.' : 'Chưa có đơn nào từ link của bạn.'; ?></td></tr>
    <?php endif; ?>
    <?php foreach ($rows as $o): [$lab, $tone] = ctv_state_label($o['state']); ?>
      <tr>
        <td><strong>#<?php echo (int)$o['id']; ?></strong><div class="muted"><?php echo (int)$o['qty']; ?> sản phẩm</div></td>
        <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($o['created_at']))); ?></td>
        <td><?php echo htmlspecialchars($o['customer']); ?></td>
        <td class="num"><?php echo vnd($o['base']); ?></td>
        <td class="num"><strong><?php echo vnd($o['commission']); ?></strong><div class="muted"><?php echo ctv_pct($o['ctv_rate']); ?>%</div></td>
        <td><span class="tag <?php echo $tone; ?>"><?php echo $lab; ?></span><div class="muted"><?php echo htmlspecialchars($o['status']); ?></div></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php echo pagination_html($pg, ['state' => $filter]); ?>
</div>
<?php require __DIR__ . '/../includes/ctv_footer.php'; ?>
