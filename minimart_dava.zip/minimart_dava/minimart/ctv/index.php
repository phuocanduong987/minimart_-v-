<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

require_collaborator();
$me = current_user();
$uid = (int)$me['id'];
$active_nav = 'index';
$page_title = 'Tổng quan';
$page_subtitle = 'Xin chào ' . $me['username'] . ' — đây là kết quả kinh doanh của bạn.';

$code = ctv_ensure_ref_code($conn, $uid);
$link = ctv_referral_link($code);
$bal = ctv_balance($conn, $uid);
$low = low_stock_threshold();

$q = $conn->prepare("SELECT COUNT(*) total,
        COALESCE(SUM(stock = 0), 0) out_n,
        COALESCE(SUM(stock > 0 AND stock <= ?), 0) low_n
    FROM products WHERE created_by = ?");
$q->bind_param('ii', $low, $uid);
$q->execute();
$pc = $q->get_result()->fetch_assoc();
$q->close();

$recent = ctv_orders($conn, $uid, 6);
$pendingReviews = ctv_pending_reviews_count($conn, $uid);

$stmt = $conn->prepare(
    "SELECT r.id, r.content, r.created_at, p.id AS pid, p.name AS pname
     FROM reviews r JOIN products p ON p.id = r.product_id
     WHERE p.created_by = ? AND NOT EXISTS (
        SELECT 1 FROM review_replies rr JOIN users x ON x.id = rr.user_id
        WHERE rr.review_id = r.id AND x.role IN ('admin','collaborator'))
     ORDER BY r.created_at DESC LIMIT 4"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$todo = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $conn->prepare("SELECT id, name, stock FROM products WHERE created_by = ? AND stock <= ? ORDER BY stock ASC, id ASC LIMIT 5");
$stmt->bind_param('ii', $uid, $low);
$stmt->execute();
$lowRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

require __DIR__ . '/../includes/ctv_header.php';
?>

<section class="ref-hero">
  <div>
    <h2>Link giới thiệu của bạn</h2>
    <p>Khách mua hàng qua link này trong 30 ngày sẽ được ghi nhận cho bạn. Hoa hồng hiện tại: <strong><?php echo ctv_pct(ctv_commission_rate($conn, $uid)); ?>%</strong> giá trị hàng hoá.</p>
    <div class="ref-box">
      <input type="text" id="ref-link" value="<?php echo htmlspecialchars($link); ?>" readonly aria-label="Link giới thiệu">
      <button type="button" class="b" data-copy="ref-link">Sao chép link</button>
    </div>
  </div>
  <div class="ref-code"><span>Mã giới thiệu</span><strong><?php echo htmlspecialchars($code); ?></strong></div>
</section>

<div class="kpis">
  <div class="kpi t-teal"><a href="payouts.php">
    <div class="kpi-label">Có thể rút</div>
    <div class="kpi-value"><?php echo vnd($bal['available']); ?></div>
    <div class="kpi-sub">Đã ghi nhận <?php echo vnd($bal['earned']); ?> · đã chi <?php echo vnd($bal['paid']); ?></div></a>
  </div>
  <div class="kpi t-warn"><a href="referrals.php">
    <div class="kpi-label">Chờ đối soát</div>
    <div class="kpi-value"><?php echo vnd($bal['pending']); ?></div>
    <div class="kpi-sub">Đơn chưa giao xong</div></a>
  </div>
  <div class="kpi"><a href="referrals.php">
    <div class="kpi-label">Đơn đã giới thiệu</div>
    <div class="kpi-value"><?php echo (int)$bal['orders']; ?></div>
    <div class="kpi-sub">Tính từ khi bạn có link</div></a>
  </div>
  <div class="kpi <?php echo ((int)$pc['out_n'] > 0) ? 't-bad' : (((int)$pc['low_n'] > 0) ? 't-warn' : ''); ?>"><a href="products.php">
    <div class="kpi-label">Sản phẩm của tôi</div>
    <div class="kpi-value"><?php echo (int)$pc['total']; ?></div>
    <div class="kpi-sub"><?php echo (int)$pc['out_n']; ?> hết hàng · <?php echo (int)$pc['low_n']; ?> sắp hết</div></a>
  </div>
</div>

<div class="adm-cols">
  <div class="card">
    <div class="card-head"><h3>Đơn giới thiệu gần đây</h3><a class="b b-ghost b-sm" href="referrals.php">Xem tất cả</a></div>
    <div class="tbl-wrap"><table>
      <tr><th>Đơn</th><th>Khách</th><th class="num">Hoa hồng</th><th>Trạng thái</th></tr>
      <?php if (!$recent): ?>
        <tr><td colspan="4" class="empty">Chưa có đơn nào. Chia sẻ link giới thiệu ở trên để bắt đầu nhận hoa hồng.</td></tr>
      <?php endif; ?>
      <?php foreach ($recent as $o): [$lab, $tone] = ctv_state_label($o['state']); ?>
        <tr>
          <td>#<?php echo (int)$o['id']; ?><div class="muted"><?php echo htmlspecialchars(date('d/m/Y', strtotime($o['created_at']))); ?></div></td>
          <td><?php echo htmlspecialchars($o['customer']); ?></td>
          <td class="num"><strong><?php echo vnd($o['commission']); ?></strong><div class="muted"><?php echo ctv_pct($o['ctv_rate']); ?>% × <?php echo vnd($o['base']); ?></div></td>
          <td><span class="tag <?php echo $tone; ?>"><?php echo $lab; ?></span><div class="muted"><?php echo htmlspecialchars($o['status']); ?></div></td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h3>Đánh giá cần trả lời</h3>
        <?php if ($pendingReviews): ?><span class="tag warn"><?php echo $pendingReviews; ?></span><?php endif; ?></div>
      <?php if (!$todo): ?>
        <p class="muted" style="margin:0;">Không có đánh giá nào đang chờ — làm tốt lắm!</p>
      <?php else: ?>
        <ul class="mini-list">
          <?php foreach ($todo as $r): ?>
            <li><div><?php echo htmlspecialchars(mb_strimwidth(strip_tags($r['content']), 0, 70, '…')); ?>
              <div class="sub"><?php echo htmlspecialchars($r['pname']); ?></div></div>
              <a class="b b-ghost b-sm" href="reviews.php?filter=pending">Trả lời</a></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h3>Sản phẩm cần nhập thêm</h3></div>
      <?php if (!$lowRows): ?>
        <p class="muted" style="margin:0;">Tồn kho các sản phẩm của bạn đang ổn.</p>
      <?php else: ?>
        <ul class="mini-list">
          <?php foreach ($lowRows as $p): ?>
            <li><span><?php echo htmlspecialchars($p['name']); ?></span>
              <span class="tag <?php echo (int)$p['stock'] === 0 ? 'bad' : 'warn'; ?>"><?php echo (int)$p['stock'] === 0 ? 'Hết hàng' : 'Còn ' . (int)$p['stock']; ?></span></li>
          <?php endforeach; ?>
        </ul>
        <p style="margin:12px 0 0;"><a class="b b-ghost b-sm" href="products.php?stock=low">Cập nhật tồn kho</a></p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/ctv_footer.php'; ?>
