<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/ctv.php';

require_collaborator();
admin_require_csrf();
$me = current_user();
$uid = (int)$me['id'];
$active_nav = 'payouts';
$page_title = 'Hoa hồng & rút tiền';
$page_subtitle = 'Theo dõi số dư và gửi yêu cầu rút hoa hồng cho quản trị viên duyệt.';
$flash = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'request') {
    $result = ctv_request_payout($conn, $uid, (float)($_POST['amount'] ?? 0), (string)($_POST['bank_info'] ?? ''));
    if ($result['ok']) {
        $flash = $result['message'];
        log_admin_action($conn, $uid, 'payout.request', '', vnd((float)($_POST['amount'] ?? 0)));
    } else {
        $error = $result['message'];
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel') {
    // Cộng tác viên huỷ yêu cầu của chính mình khi còn "Chờ duyệt".
    $pid = (int)($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM ctv_payouts WHERE id = ? AND user_id = ? AND status = 'Chờ duyệt'");
    $stmt->bind_param('ii', $pid, $uid);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        $flash = 'Đã huỷ yêu cầu rút tiền.';
        log_admin_action($conn, $uid, 'payout.cancel', "#$pid");
    } else {
        $error = 'Không thể huỷ yêu cầu này (đã được xử lý hoặc không phải của bạn).';
    }
}

$bal = ctv_balance($conn, $uid);

$stmt = $conn->prepare("SELECT id, amount, bank_info, status, admin_note, created_at, processed_at
                        FROM ctv_payouts WHERE user_id = ? ORDER BY id DESC LIMIT 50");
$stmt->bind_param('i', $uid);
$stmt->execute();
$history = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

require __DIR__ . '/../includes/ctv_header.php';
admin_flash($flash, $error);
?>
<div class="bal">
  <div class="kpi big t-teal"><div class="kpi-label">Có thể rút</div><div class="kpi-value"><?php echo vnd($bal['available']); ?></div><div class="kpi-sub">Đã ghi nhận − đã chi − đang chờ duyệt</div></div>
  <div class="kpi"><div class="kpi-label">Tổng đã ghi nhận</div><div class="kpi-value"><?php echo vnd($bal['earned']); ?></div><div class="kpi-sub">Từ các đơn đã giao</div></div>
  <div class="kpi t-warn"><div class="kpi-label">Chờ đối soát</div><div class="kpi-value"><?php echo vnd($bal['pending']); ?></div><div class="kpi-sub">Đơn chưa giao xong</div></div>
  <div class="kpi"><div class="kpi-label">Đã nhận</div><div class="kpi-value"><?php echo vnd($bal['paid']); ?></div><div class="kpi-sub">Đang chờ duyệt: <?php echo vnd($bal['reserved']); ?></div></div>
</div>

<div class="adm-cols">
  <div class="card">
    <div class="card-head"><h3>Lịch sử rút tiền</h3></div>
    <div class="tbl-wrap"><table>
      <tr><th>Mã</th><th>Ngày gửi</th><th class="num">Số tiền</th><th>Nhận về</th><th>Trạng thái</th><th></th></tr>
      <?php if (!$history): ?><tr><td colspan="6" class="empty">Bạn chưa gửi yêu cầu rút tiền nào.</td></tr><?php endif; ?>
      <?php foreach ($history as $h): ?>
        <tr>
          <td>#<?php echo (int)$h['id']; ?></td>
          <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($h['created_at']))); ?></td>
          <td class="num"><strong><?php echo vnd($h['amount']); ?></strong></td>
          <td class="muted"><?php echo htmlspecialchars($h['bank_info']); ?></td>
          <td><span class="tag <?php echo ctv_payout_tone($h['status']); ?>"><?php echo htmlspecialchars($h['status']); ?></span>
            <?php if (!empty($h['admin_note'])): ?><div class="muted">Ghi chú: <?php echo htmlspecialchars($h['admin_note']); ?></div><?php endif; ?></td>
          <td>
            <?php if ($h['status'] === 'Chờ duyệt'): ?>
              <form method="post" onsubmit="return confirm('Huỷ yêu cầu rút tiền này?');">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="cancel">
                <input type="hidden" name="id" value="<?php echo (int)$h['id']; ?>">
                <button type="submit" class="b b-danger b-sm">Huỷ</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>

  <div class="card">
    <h3>Gửi yêu cầu rút tiền</h3>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="request">
      <label for="amount">Số tiền (đ)</label>
      <input type="number" id="amount" name="amount" min="<?php echo CTV_MIN_PAYOUT; ?>" step="1000" max="<?php echo (int)$bal['available']; ?>" required
             placeholder="Tối thiểu <?php echo number_format(CTV_MIN_PAYOUT, 0, ',', '.'); ?>">
      <div class="hint">Tối đa <?php echo vnd($bal['available']); ?> · Tối thiểu <?php echo vnd(CTV_MIN_PAYOUT); ?>.</div>

      <label for="bank_info">Thông tin nhận tiền</label>
      <textarea id="bank_info" name="bank_info" maxlength="255" required placeholder="Ngân hàng · Số tài khoản · Tên chủ tài khoản"></textarea>

      <div class="form-actions">
        <button type="submit" class="b" <?php echo $bal['available'] < CTV_MIN_PAYOUT ? 'disabled' : ''; ?>>Gửi yêu cầu</button>
      </div>
      <?php if ($bal['available'] < CTV_MIN_PAYOUT): ?>
        <div class="hint">Bạn cần tối thiểu <?php echo vnd(CTV_MIN_PAYOUT); ?> hoa hồng đã ghi nhận để rút.</div>
      <?php endif; ?>
    </form>
  </div>
</div>
<?php require __DIR__ . '/../includes/ctv_footer.php'; ?>
